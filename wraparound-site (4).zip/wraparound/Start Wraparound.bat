@echo off
title Wraparound
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 goto nonode
node -e "const v=process.versions.node.split('.').map(Number);process.exit(v[0]>22||(v[0]===22&&v[1]>=5)?0:1)"
if errorlevel 1 goto oldnode
set OPEN_BROWSER=1
echo Starting Wraparound...
node --no-warnings server.js
echo.
echo Wraparound has stopped.
pause
exit /b

:nonode
echo.
echo Wraparound needs Node.js, which is not installed on this computer.
echo I'll open the download page. Install the "LTS" version, then double-click this file again.
start https://nodejs.org/en/download
echo.
pause
exit /b

:oldnode
echo.
echo Your Node.js is too old. Wraparound needs version 22.5 or newer.
echo I'll open the download page. Install the "LTS" version, then double-click this file again.
start https://nodejs.org/en/download
echo.
pause
exit /b
