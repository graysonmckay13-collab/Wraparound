#!/bin/bash
# Double-click this file on a Mac to start Wraparound.
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo
  echo "Wraparound needs Node.js, which is not installed on this Mac."
  echo "Opening the download page. Install the \"LTS\" version, then double-click this file again."
  open "https://nodejs.org/en/download" 2>/dev/null
  echo; read -n 1 -s -r -p "Press any key to close."; exit 1
fi
if ! node -e "const v=process.versions.node.split('.').map(Number);process.exit(v[0]>22||(v[0]===22&&v[1]>=5)?0:1)"; then
  echo
  echo "Your Node.js is too old. Wraparound needs version 22.5 or newer."
  open "https://nodejs.org/en/download" 2>/dev/null
  echo; read -n 1 -s -r -p "Press any key to close."; exit 1
fi
export OPEN_BROWSER=1
echo "Starting Wraparound..."
node --no-warnings server.js
echo; echo "Wraparound has stopped."; read -n 1 -s -r -p "Press any key to close."
