'use strict';
// Usage: node scripts/reset-password.js someone@example.com "a new password"
// Run it on the server, with the same DATA_DIR the site uses. Handy if the owner is locked out.
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const [email, pw] = process.argv.slice(2);
if (!email || !pw || pw.length < 8) { console.error('Usage: node scripts/reset-password.js email "new password (8+ characters)"'); process.exit(1); }
const dataDir = path.resolve(process.env.DATA_DIR || path.join(__dirname, '..', 'data'));
const db = new DatabaseSync(path.join(dataDir, 'wraparound.db'));
const u = db.prepare('SELECT id FROM users WHERE email=?').get(email.trim().toLowerCase());
if (!u) { console.error('No account with that email.'); process.exit(1); }
const salt = crypto.randomBytes(16);
const hash = 's1:' + salt.toString('hex') + ':' + crypto.scryptSync(pw, salt, 64).toString('hex');
db.prepare('UPDATE users SET pass=? WHERE id=?').run(hash, u.id);
db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);
console.log('Password updated. They have been signed out everywhere.');
