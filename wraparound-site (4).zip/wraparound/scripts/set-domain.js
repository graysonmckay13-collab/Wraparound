'use strict';
/*
 * Sets your site's name and web address in one go. It writes .env and Caddyfile for you.
 *   node scripts/set-domain.js "Headset Club" headsetclub.com
 *   node scripts/set-domain.js "Headset Club"        (suggests headsetclub.com)
 *   node scripts/set-domain.js                         (asks you)
 * This does not buy the domain. Buy it at a registrar first, then point its DNS at your server.
 */
const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline/promises');
const root = path.join(__dirname, '..');
const slug = (n) => String(n).toLowerCase().replace(/[^a-z0-9]/g, '');

function apply(name, domain) {
  domain = domain.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  if (!/^([a-z0-9-]+\.)+[a-z]{2,}$/.test(domain)) throw new Error('"' + domain + '" does not look like a web address. Try something like mysite.com');
  const envPath = path.join(root, '.env'), example = path.join(root, '.env.example');
  let env = fs.existsSync(envPath) ? fs.readFileSync(envPath, 'utf8') : fs.readFileSync(example, 'utf8');
  const set = (k, v) => { const re = new RegExp('^' + k + '=.*$', 'm'); env = re.test(env) ? env.replace(re, k + '=' + v) : env.replace(/\n*$/, '\n') + k + '=' + v + '\n'; };
  set('SITE_NAME', name); set('PUBLIC_URL', 'https://' + domain);
  fs.writeFileSync(envPath, env);
  const cp = path.join(root, 'Caddyfile');
  if (fs.existsSync(cp)) fs.writeFileSync(cp, fs.readFileSync(cp, 'utf8').replace(/^[^\s#{][^\n{]*\{/m, domain + ' {'));
  return domain;
}
async function main() {
  let [name, domain] = process.argv.slice(2);
  if (!name || !domain) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    if (!name) name = (await rl.question('What is your site called? ')).trim();
    if (!name) { console.error('A name is needed.'); process.exit(1); }
    if (!domain) { const guess = slug(name) + '.com'; domain = (await rl.question('Web address [' + guess + ']: ')).trim() || guess; }
    rl.close();
  }
  if (!domain) domain = slug(name) + '.com';
  const d = apply(name.trim(), domain);
  console.log('\nDone.\n  Site name:    ' + name.trim() + '\n  Web address:  https://' + d + '\n\nWritten to .env and Caddyfile.\nNext: buy ' + d + ' if you have not already, point its DNS "A record" at your server, then start the site with: docker compose up -d');
}
if (require.main === module) main().catch((e) => { console.error(e.message); process.exit(1); });
module.exports = { apply, slug };
