'use strict';
/*
 * Launcher. This is what you start (node server.js). It runs the site from the "app" folder, keeps it running,
 * restarts it when the admin panel asks, and switches back to the previous version if a freshly installed
 * version crashes as it starts. It is deliberately small, and updates never replace it.
 */
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const DATA = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const STATE = path.join(DATA, 'versions.json');
const BUNDLED = path.join(__dirname, 'app');
fs.mkdirSync(DATA, { recursive: true });

const log = (m) => console.log('[launcher] ' + m);
const readState = () => { try { return { current: 'bundled', previous: null, failed: null, history: [], ...JSON.parse(fs.readFileSync(STATE, 'utf8')) }; } catch (e) { return { current: 'bundled', previous: null, failed: null, history: [] }; } };
const writeState = (s) => { fs.writeFileSync(STATE + '.tmp', JSON.stringify(s, null, 2)); fs.renameSync(STATE + '.tmp', STATE); };
const dirFor = (id) => (id === 'bundled' ? BUNDLED : path.join(DATA, 'versions', id, 'app'));

let child = null, stopping = false, startedAt = 0, first = true, crashes = 0;

function start() {
  let st = readState();
  if (!fs.existsSync(path.join(dirFor(st.current), 'main.js'))) {
    log('Version "' + st.current + '" is missing. Using the built-in version.');
    st = { ...st, current: 'bundled', previous: null }; writeState(st);
  }
  startedAt = Date.now();
  const env = { ...process.env, SUPERVISED: '1', APP_VERSION_ID: st.current, BUNDLED_APP_DIR: BUNDLED, DATA_DIR: DATA };
  if (!first) env.OPEN_BROWSER = '0';
  first = false;
  child = spawn(process.execPath, ['--no-warnings', path.join(dirFor(st.current), 'main.js')], { stdio: 'inherit', env });
  child.on('exit', (code, signal) => {
    child = null;
    if (stopping) return process.exit(0);
    const ranFor = Date.now() - startedAt;
    if (code === 75) { log('Restarting.'); crashes = 0; return setTimeout(start, 300); }                 // restart asked for
    if (code === 0) return process.exit(0);                                                                 // clean stop
    if (code === 78) return process.exit(1);                                                                // configuration problem, do not loop
    const cur = readState();
    if (ranFor < 20000 && cur.current !== 'bundled') {                                                     // new version crashed on start
      const back = cur.previous && fs.existsSync(path.join(dirFor(cur.previous), 'main.js')) ? cur.previous : 'bundled';
      log('Version "' + cur.current + '" crashed as it started. Going back to "' + back + '".');
      cur.history.push({ at: Date.now(), event: 'auto-rollback', from: cur.current, to: back });
      cur.failed = cur.current; cur.current = back; cur.previous = null; writeState(cur);
      return setTimeout(start, 500);
    }
    crashes = ranFor < 10000 ? crashes + 1 : 0;
    const wait = Math.min(30000, 2000 * 2 ** Math.min(crashes, 4));
    log('The site stopped unexpectedly (' + (signal || 'code ' + code) + '). Starting it again in ' + Math.round(wait / 1000) + ' seconds.');
    setTimeout(start, wait);
  });
}

['SIGINT', 'SIGTERM'].forEach((sig) => process.on(sig, () => {
  stopping = true;
  if (child) child.kill(sig); else process.exit(0);
  setTimeout(() => process.exit(0), 6000).unref();
}));
start();
