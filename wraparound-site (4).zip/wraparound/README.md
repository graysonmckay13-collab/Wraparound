# Wraparound

A small social site for VR clips. Members post videos of what they played (including 360° videos that
others can look around inside), follow each other, become friends, message, start groups and join video calls.
The first account is the owner and gets an admin panel.

It runs on its own. There is no Claude, no third-party backend and nothing to install from npm:
a small Node.js program, one SQLite database file and a folder of uploaded videos.

## What is in it

- Accounts: email and password, **Sign in with Google**, **Sign in with Apple**
- Clips feed ("Everyone" and "Following"), likes, comments, reports
- Video upload (MP4 or WebM, up to 200 MB by default) with progress; 360° (equirectangular) videos play in a WebGL viewer you can drag to look around
- Follow people, friend requests, direct messages (text and video)
- Groups with chat
- Video and voice calls, 1:1 and group (up to 6 people), straight between browsers, with ringtones, join and leave chimes, a microphone level bar on every tile, and a built-in test page for your camera, microphone and speakers
- Rules, Terms, Privacy and Contact pages (`/rules`, `/terms`, `/privacy`, `/contact`) with editable starting text, an agreement box at sign-up, and members can download their data and delete their own account
- Admin panel, for the owner only: a launch checklist, stats, members (approve, ban, reset password, delete), reports, all posts, invite links, who can sign up, the **Policies** and **Site** tabs for editing the text, and an **Update** tab for installing new versions
- Sign-up modes: invite only (default), approval, open, closed

## Run it on your computer

**Quickest:** double-click `Start Wraparound.bat` (Windows) or `Start Wraparound.command` (Mac). It checks you have
Node.js, starts the site and opens your browser. See `START HERE.txt`.

Or by hand:

You need Node.js 22.5 or newer.

```
node server.js
```

Open http://localhost:3000 and create the first account. That account is the owner.
Everything is stored in the `data` folder next to `server.js`.

Calls need a secure connection (https) except on `localhost`, so test them with two browser windows on the same machine
or put the site online first.

## Put it online

You need a host that can run Node 22+, keeps a **persistent disk** (the database and videos live on it),
and gives you HTTPS. Free hosting tiers that wipe the disk on restart will lose everything, so avoid those.

**Easiest: any small server with Docker** (a $5 to $6 per month VPS from Hetzner, DigitalOcean, Linode and so on):

1. Point your domain's DNS at the server's IP address.
2. Copy this folder to the server.
3. Put your domain in `Caddyfile`, and copy `.env.example` to `.env` and fill it in (at least `PUBLIC_URL`).
4. `docker compose up -d`

Caddy fetches and renews the HTTPS certificate for you. Your site is then live at your domain.

**Render, Railway, Fly.io:** use the `Dockerfile`, attach a persistent volume mounted at `/data`, set the environment
variables from `.env.example` in their dashboard, and make sure the plan lets the app run continuously (live updates and calls need that).

Run **one** copy of the app only. Live updates and call rooms are kept in memory, so don't scale to several instances.

## Settings (environment variables)

| Variable | What it does |
| --- | --- |
| `PUBLIC_URL` | Your site's address, e.g. `https://wraparound.example.com`. Required for Google and Apple sign-in. |
| `SIGNUP_MODE` | `invite` (default), `approval`, `open`, `closed`. Changeable later in the admin panel. |
| `ADMIN_EMAIL` | Lets someone who registers with this email become the admin, but only while the site has no admin at all (a safety net if the owner account is ever lost). |
| `MAX_UPLOAD_MB` | Largest video, default 200. Photos (profile pictures) are limited to 8 MB. |
| `DATA_DIR` | Where the database and videos live. Back it up. |
| `TRUST_PROXY` | Set to `1` behind Caddy, nginx or a host's proxy. |
| `SITE_NAME` | Shown in the header. |
| `GOOGLE_*`, `APPLE_*` | Sign-in providers, see below. |
| `TURN_URL`, `TURN_USER`, `TURN_PASS` | Optional relay server for calls, see below. |

## Who can do what

There is one admin: the owner, which is the first account created on the site. Admin rights can't be handed to anyone else, not even
by the owner, and the admin pages and API refuse everyone else.

- **Edit the site's wording** (name, headline, intro): Admin, then **Site**. It goes live for everyone straight away.
- **Edit the site's code or look, and publish it:** the code lives on your server, so only whoever has your hosting login (you) can change it.
  Change the files, restart the app (or run `docker compose up -d --build`), and the new version is live. Nobody can change it from inside the site.

## Your web address

Visiting `yourname.com` takes three things: buy the domain, point it at your server, and tell the site about it.

1. **Buy the domain** at a registrar such as Cloudflare, Porkbun or Namecheap. This can't be done for you, and short common words are
   often already taken, so check that the name you want is free before you commit to it.
2. **Tell the site:** run `node scripts/set-domain.js "Your Site Name" yourname.com`. It writes `.env` and `Caddyfile` for you.
   (Run it with just the name and it suggests the name plus `.com`.)
3. **Point the domain at your server:** in the registrar's DNS settings, add an `A` record for `yourname.com` pointing to your server's IP address.
   Then `docker compose up -d`. Caddy sets up HTTPS by itself.

## Keeping it to real people

Leave sign-ups on **invite only**. In the admin panel, open **Invites**, create some, and send each person their link.
Each link works once. Google and Apple sign-in respect this too: a new person has to open an invite link first.
If you'd rather let anyone ask, switch to **Approve each person** and approve them from **People**.

There is no email verification (that would need an email service). Invite-only or approval mode is how you keep it real.

## Sign in with Google

1. Go to https://console.cloud.google.com, create a project, and set up the **OAuth consent screen**.
2. **APIs & Services → Credentials → Create credentials → OAuth client ID → Web application**.
3. Under **Authorized redirect URIs** add `https://YOUR-DOMAIN/auth/google/callback`.
4. Put the client ID and secret in `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`, set `PUBLIC_URL`, restart.

The "Continue with Google" button appears on its own once those are set.

## Sign in with Apple

This needs the Apple Developer Program (US$99 per year) and a real domain with HTTPS. Apple does not allow `localhost`.

1. In **Certificates, Identifiers & Profiles**, create an **App ID** with *Sign in with Apple* turned on.
2. Create a **Services ID**. Its identifier is your `APPLE_CLIENT_ID`. Turn on *Sign in with Apple* for it, add your domain,
   and add the return URL `https://YOUR-DOMAIN/auth/apple/callback`.
3. Under **Keys**, create a key with *Sign in with Apple*. Download the `.p8` file once (Apple won't show it again) and note the **Key ID**.
4. Your **Team ID** is shown at the top right of the developer account page.
5. Set `APPLE_CLIENT_ID`, `APPLE_TEAM_ID`, `APPLE_KEY_ID`, and either `APPLE_PRIVATE_KEY` (the file contents, with line breaks written as `\n`) or `APPLE_PRIVATE_KEY_FILE`. Restart.

Apple and Google's own design rules ask for their logo on the button. The buttons here are plain text, so add the official
logo images if you want to follow those rules to the letter.

How accounts match up: signing in with Google or Apple finds the account that was created with it. It never silently joins an
existing email-and-password account with the same address (that could let someone take over an account). Instead the person
signs in with their password and presses **Connect** under *Sign-in methods* on their profile.

## Calls

Audio and video go directly between browsers; the server only passes the connection messages. Everyone in a call connects to
everyone else, so calls are capped at 6 people. The built-in public STUN servers are enough for most home and mobile connections.
Some office, school and mobile networks block direct connections; for those, run a TURN server
([coturn](https://github.com/coturn/coturn) is free) or rent one, and set `TURN_URL` (for example `turn:turn.example.com:3478`), `TURN_USER`, `TURN_PASS`.

Calls need HTTPS and the browser's permission to use the camera and microphone.

**Sound.** The person being called hears a ringtone and the caller hears a ringback tone; chimes play when someone joins or leaves, and a bar on each tile moves when that person speaks. Some phones and browsers block audio until you tap, so a **Turn on sound** button appears in the call if that happens. Sounds can be switched off under *Your profile*. To check your own setup without needing a second person, use **Test camera and mic** on the Friends page: it shows your camera, moves a bar as you speak, and plays a test sound.

## Rules, terms and privacy

The site ships with plain-language starting versions of the **Community rules**, **Terms of use** and **Privacy policy**, plus a **Contact**
page. They are public pages (`yoursite.com/rules`, `/terms`, `/privacy`, `/contact`), which is also where Google and Apple expect to
find your privacy policy and terms when you set up sign-in.

- Edit them in **Admin, then Policies**: your contact email, your name or company name, the minimum age, and the full text of each page.
  Each has a **Reset to starting text** button.
- Everyone has to tick a box agreeing to the Rules, Terms and Privacy Policy when they join, including when they join with Google or
  Apple. The site records when they agreed and which version of the policies was current.
- Members can **download their data** and **delete their account** from *Your profile*, which is what privacy laws and Apple expect.
- Anything written `[[like this]]` in a policy is a blank you still have to fill in. It shows highlighted on the page and keeps the
  launch checklist from turning green.

These texts are a starting point, not legal advice. Have a lawyer read them before you open the site to the public, and change anything that
does not match how you actually run it.

## Before you open it to the public

The **Overview** tab in the admin panel has a "Before you publish" checklist that ticks itself off. The must-do items are:

1. A contact email (Admin, then Policies).
2. Nothing left in `[[brackets]]` in the policies (the governing-law line in the Terms is one).
3. Your web address is set and uses https (see "Your web address").

Things the checklist can't check, but you should think about before inviting strangers:

- **Moderation.** You (and only you) can remove posts and ban people. Decide how often you will look at **Reports**. Invite-only keeps this manageable.
- **Child safety.** If a post shows a child being sexually exploited, remove it, keep the details and report it. In the US the place to report is the NCMEC CyberTipline
  (report.cybertip.org), and providers in the US are required to report apparent child sexual abuse material when they find it. Other countries have their own hotlines.
- **Copyright.** The Terms explain how someone sends you a takedown request. In the US you can also register a "designated agent" with the Copyright Office to get
  the DMCA safe-harbour protections; that is worth doing if you run this publicly.
- **Privacy law.** If you have members in the EU, UK or California you are expected to honour access, deletion and correction requests. Download-my-data and delete-my-account
  cover most of it; for anything else people will email your contact address.
- **Backups.** Download a database backup from Admin, then Update, and copy the `uploads` folder too. Do it before anything risky.

## Updating the site

When you have a new version (an `update zip`), install it from the site itself: **Admin, then Update**.

1. Choose the zip and press **Check the update**. The site unpacks it, checks every file, and test-starts the new version on a spare port with an empty
   temporary database. If anything is wrong it tells you in plain words and nothing changes.
2. You see what changed (files added, changed, removed) and the version's notes. Press **Install and restart** and confirm with your password.
3. The site backs up your database, switches to the new version and restarts for a few seconds. The page reloads itself.
4. If you don't like it, **Go back** returns to the previous version in one click. If a new version crashes as it starts, the launcher switches back by itself.

Posts, members, messages and videos live in your data folder and are never touched by an update. New versions only ever add to the database,
so going back is safe.

How it works: `server.js` is a small launcher that runs the site from the `app` folder, restarts it when asked, and keeps installed versions in
`DATA_DIR/versions`. They survive restarts, Docker rebuilds and moving to a new server (as long as the data folder comes with you).
An update zip is the `app` folder, zipped. You can also update by hand: replace the `app` folder and restart.

One safety note: an update is program code that runs on your server. Only install update zips that came from you or from someone you trust,
and keep the owner password strong. Updates need the site to be started the normal way (`node server.js`, the Start file, or Docker).

## Looking after it

- **Backups:** Admin, then Update, then **Download a database backup** gives you a clean copy of the database at any time (the site also keeps its own copies in `DATA_DIR/backups`, including one before every update). To back up everything, copy the whole `DATA_DIR`: the database, `uploads/`, `versions/` and `secret.key`.
- **Locked out:** on the server run `node scripts/reset-password.js you@example.com "new password"`.
- **Updating:** use Admin, then Update (see above). The database upgrades itself; tables and columns are only ever added.
- **Disk space:** the admin Overview shows how much the videos use. Videos are stored as uploaded; nothing is re-encoded.
  Browsers play H.264 MP4 and VP9 WebM best. A clip exported in an unusual format may not play for everyone.

## Things this does not do (yet)

- No email verification, and no "forgot password" email. The admin can set a new password for a member.
- No push notifications; live updates only arrive while the site is open.
- No automatic moderation. Members report posts, you review them in **Reports**.
- No video re-encoding or thumbnails, and no resumable uploads.
- Group chats are open to every member who joins the group, and the owner can read anything on the server, so don't promise members private messaging.
- One server only.
- Legal side: if you run this for the public you are responsible for a privacy notice, terms, handling takedown requests, and any
  age rules where you live. Keep it invite-only if you want to stay small and simple.

## Tests

```
npm test
```

Starts the real launcher and server on a temporary folder and exercises the whole HTTP API (accounts, invites, uploads and range requests,
posts, follows, friends, direct messages, groups, call signalling, admin actions, and file clean-up). A second test runs
Google and Apple sign-in against a mock provider that issues real signed tokens, including forged and expired ones. A third installs real zip packages through the Update feature, rolls back, and checks that a crashing version is rolled back automatically.

What those tests can't cover: the screens themselves in a real browser, the 360° viewer, real camera and microphone calls between
two devices, and your real Google or Apple credentials. Before you open the doors, walk through this once on a phone and a laptop:
create the owner account, post a clip, post a 360° clip and drag around in it, invite a second person, friend each other, message, start a call on two devices,
and sign in with each provider you enabled.
