'use strict';
/* A small, strict ZIP reader (no dependencies). Reads "stored" and "deflate" entries only. */
const zlib = require('node:zlib');

const LIMITS = { entries: 4000, file: 25 * 1024 * 1024, total: 150 * 1024 * 1024 };

function safeName(name) {
  const n = String(name).replace(/\\/g, '/');
  if (!n || n.startsWith('/') || /^[A-Za-z]:/.test(n) || n.includes('\0')) return null;
  const parts = n.split('/');
  if (parts.some((p) => p === '..')) return null;
  return parts.filter((p) => p && p !== '.').join('/');
}

function readZip(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 22) throw new Error('That is not a zip file.');
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 22 - 65535); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('That is not a zip file.');
  const count = buf.readUInt16LE(eocd + 10), cdOff = buf.readUInt32LE(eocd + 16);
  if (count === 0xffff || cdOff === 0xffffffff) throw new Error('Zip64 archives are not supported.');
  if (count > LIMITS.entries) throw new Error('That zip has too many files.');
  const entries = []; let p = cdOff, total = 0;
  for (let n = 0; n < count; n++) {
    if (p + 46 > buf.length || buf.readUInt32LE(p) !== 0x02014b50) throw new Error('The zip file is damaged.');
    const flags = buf.readUInt16LE(p + 8), method = buf.readUInt16LE(p + 10), crc = buf.readUInt32LE(p + 16), csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nl = buf.readUInt16LE(p + 28), el = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), off = buf.readUInt32LE(p + 42);
    const raw = buf.toString(flags & 0x800 ? 'utf8' : 'latin1', p + 46, p + 46 + nl);
    p += 46 + nl + el + cl;
    if (raw.endsWith('/') || raw.endsWith('\\')) continue; // folder
    if (flags & 1) throw new Error('Password-protected zips are not supported.');
    const name = safeName(raw);
    if (!name) throw new Error('The zip contains an unsafe file path (' + raw.slice(0, 60) + ').');
    if (usize > LIMITS.file) throw new Error('A file inside the zip is too large.');
    total += usize; if (total > LIMITS.total) throw new Error('The zip is too large when unpacked.');
    entries.push({ name, method, crc, csize, usize, off });
  }
  function read(e) {
    if (e.off + 30 > buf.length || buf.readUInt32LE(e.off) !== 0x04034b50) throw new Error('The zip file is damaged.');
    const start = e.off + 30 + buf.readUInt16LE(e.off + 26) + buf.readUInt16LE(e.off + 28);
    const data = buf.subarray(start, start + e.csize);
    let out;
    if (e.method === 0) out = Buffer.from(data);
    else if (e.method === 8) { try { out = zlib.inflateRawSync(data, { maxOutputLength: e.usize + 1 }); } catch (err) { throw new Error('The zip file is damaged.'); } }
    else throw new Error('This zip uses a compression method that is not supported.');
    if (out.length !== e.usize) throw new Error('The zip file is damaged.');
    if (typeof zlib.crc32 === 'function' && (zlib.crc32(out) >>> 0) !== e.crc) throw new Error('The zip file is damaged (checksum mismatch).');
    return out;
  }
  return { entries, read };
}

module.exports = { readZip, safeName, LIMITS };
