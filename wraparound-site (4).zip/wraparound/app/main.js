'use strict';
/*
 * Wraparound server. No dependencies. Needs Node 22.5 or newer (uses the built-in SQLite).
 * Configuration is by environment variables, see .env.example and README.md.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const POL = require('./policies.js');

/* ---------- config ---------- */
const CFG = {
  port: +process.env.PORT || 3000,
  dataDir: path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data')),
  siteName: process.env.SITE_NAME || 'Wraparound',
  signupDefault: process.env.SIGNUP_MODE || 'invite', // open | approval | invite | closed
  adminEmail: (process.env.ADMIN_EMAIL || '').trim().toLowerCase(),
  maxUploadMb: +process.env.MAX_UPLOAD_MB || 200,
  publicUrl: (process.env.PUBLIC_URL || '').replace(/\/+$/, ''),
  secureCookie: process.env.COOKIE_SECURE === '1' || /^https:/i.test(process.env.PUBLIC_URL || ''),
  trustProxy: process.env.TRUST_PROXY === '1',
  turn: { url: process.env.TURN_URL || '', user: process.env.TURN_USER || '', pass: process.env.TURN_PASS || '' }
};
const IMAGE_MAX = 8 * 1024 * 1024;
const VIDEO_MAX = CFG.maxUploadMb * 1024 * 1024;
const UPLOADS = path.join(CFG.dataDir, 'uploads');
fs.mkdirSync(UPLOADS, { recursive: true });
const PUBLIC = path.join(__dirname, 'public');

/* ---------- database ---------- */
const db = new DatabaseSync(path.join(CFG.dataDir, 'wraparound.db'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  handle TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  pass TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  status TEXT NOT NULL DEFAULT 'active',
  bio TEXT NOT NULL DEFAULT '',
  avatar TEXT,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions(
  hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS identities(
  provider TEXT NOT NULL,
  subject TEXT NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  email TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  PRIMARY KEY(provider, subject)
);
CREATE TABLE IF NOT EXISTS invites(
  code TEXT PRIMARY KEY,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  used_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  note TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS media(
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  mime TEXT NOT NULL,
  bytes INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS posts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  text TEXT NOT NULL DEFAULT '',
  media_id TEXT,
  is360 INTEGER NOT NULL DEFAULT 0,
  game TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS posts_user ON posts(user_id, id);
CREATE TABLE IF NOT EXISTS likes(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  PRIMARY KEY(user_id, post_id)
);
CREATE TABLE IF NOT EXISTS comments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS comments_post ON comments(post_id, id);
CREATE TABLE IF NOT EXISTS follows(
  follower_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  followee_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY(follower_id, followee_id)
);
CREATE TABLE IF NOT EXISTS friendships(
  requester_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  addressee_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at INTEGER NOT NULL,
  PRIMARY KEY(requester_id, addressee_id)
);
CREATE TABLE IF NOT EXISTS groups(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS group_members(
  group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  joined_at INTEGER NOT NULL,
  PRIMARY KEY(group_id, user_id)
);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room TEXT NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  text TEXT NOT NULL DEFAULT '',
  media_id TEXT,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS messages_room ON messages(room, id);
CREATE TABLE IF NOT EXISTS reports(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  reporter_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  resolved INTEGER NOT NULL DEFAULT 0
);
`);

{
  const cols = db.prepare('PRAGMA table_info(users)').all().map((c) => c.name);
  if (!cols.includes('accepted_at')) db.exec('ALTER TABLE users ADD COLUMN accepted_at INTEGER');
  if (!cols.includes('terms_version')) db.exec('ALTER TABLE users ADD COLUMN terms_version TEXT');
}

const now = () => Date.now();
const one = (sql, ...a) => db.prepare(sql).get(...a);
const all = (sql, ...a) => db.prepare(sql).all(...a);
const run = (sql, ...a) => db.prepare(sql).run(...a);
const tx = fn => { db.exec('BEGIN'); try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; } };

const STARTED_AT = Date.now();
const APP_VERSION = (() => { try { return String(JSON.parse(fs.readFileSync(path.join(__dirname, 'version.json'), 'utf8')).version); } catch (e) { return '?'; } })();
function backupDb(label) {
  const dir = path.join(CFG.dataDir, 'backups'); fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14), file = path.join(dir, `db-${stamp}-${label}.sqlite`);
  db.prepare('VACUUM INTO ?').run(file);
  const files = fs.readdirSync(dir).filter((f) => f.endsWith('.sqlite')).sort();
  files.slice(0, Math.max(0, files.length - 10)).forEach((f) => fs.rmSync(path.join(dir, f), { force: true }));
  return file;
}
const UPDATER = require('./updater.js').createUpdater({ dataDir: CFG.dataDir, appDir: __dirname, backupDb });

const getSetting = (k, d) => { const r = one('SELECT value FROM settings WHERE key=?', k); return r ? r.value : d; };
const setSetting = (k, v) => run('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', k, v);
const signupMode = () => getSetting('signup_mode', CFG.signupDefault);
const siteName = () => getSetting('site_name', CFG.siteName);
const policyText = (k) => getSetting('policy_' + k, '') || POL.DEFAULTS[k];
const policiesStamp = () => { let v = getSetting('policies_updated', ''); if (!v) { v = String(Date.now()); setSetting('policies_updated', v); } return v; };
function policyVars() {
  const site = siteName(), contact = getSetting('contact_email', ''), op = getSetting('operator', '');
  return { site, min_age: getSetting('min_age', '16'), contact: contact || '[[contact email not set yet]]', operator: op || 'the owner of ' + site, domain: CFG.publicUrl.replace(/^https?:\/\//, '') || 'this site' };
}

/* ---------- small utilities ---------- */
class HttpError extends Error { constructor(code, msg) { super(msg); this.code = code; } }
const bad = (msg = 'Bad request') => new HttpError(400, msg);
const rid = (n = 16) => crypto.randomBytes(n).toString('hex');
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const userCols = 'u.id,u.handle,u.name,u.bio,u.avatar';
const pubUser = r => r && { id: r.id, handle: r.handle, name: r.name, bio: r.bio || '', avatar: r.avatar ? '/media/' + r.avatar : null };
const clip = (s, n) => String(s == null ? '' : s).replace(/\u0000/g, '').trim().slice(0, n);

function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(pw, salt, 64);
  return 's1:' + salt.toString('hex') + ':' + h.toString('hex');
}
function checkPassword(pw, stored) {
  const [v, s, h] = String(stored).split(':');
  if (v !== 's1') return false;
  const a = crypto.scryptSync(pw, Buffer.from(s, 'hex'), 64), b = Buffer.from(h, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const buckets = new Map();
function limit(key, max, windowMs) {
  const t = now(); let b = buckets.get(key);
  if (!b || b.reset < t) { b = { n: 0, reset: t + windowMs }; buckets.set(key, b); }
  if (++b.n > max) throw new HttpError(429, 'Too many attempts. Try again in a few minutes.');
}
setInterval(() => { const t = now(); buckets.forEach((b, k) => { if (b.reset < t) buckets.delete(k); }); }, 60000).unref();
const ipOf = req => (CFG.trustProxy && (req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || 'x';

function json(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}
function readJson(req, max = 100 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > max) { reject(new HttpError(413, 'Request too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { if (!chunks.length) return resolve({}); try { const v = JSON.parse(Buffer.concat(chunks).toString('utf8')); resolve(v && typeof v === 'object' ? v : {}); } catch (e) { reject(bad('Invalid JSON')); } });
    req.on('error', reject);
  });
}
const parseCookies = h => Object.fromEntries(String(h || '').split(';').map(s => s.trim()).filter(Boolean).map(s => { const i = s.indexOf('='); return [s.slice(0, i), decodeURIComponent(s.slice(i + 1))]; }));

/* ---------- sessions ---------- */
function createSession(res, userId) {
  const token = rid(32);
  run('INSERT INTO sessions(hash,user_id,expires_at) VALUES(?,?,?)', sha(token), userId, now() + 30 * 864e5);
  res.setHeader('Set-Cookie', `sid=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${30 * 86400}${CFG.secureCookie ? '; Secure' : ''}`);
}
function clearCookie(res) { res.setHeader('Set-Cookie', `sid=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${CFG.secureCookie ? '; Secure' : ''}`); }
function sessionUser(req) {
  const tok = parseCookies(req.headers.cookie).sid; if (!tok) return null;
  const r = one('SELECT u.id,u.handle,u.name,u.email,u.role,u.status,u.bio,u.avatar,s.expires_at FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.hash=?', sha(tok));
  if (!r || r.expires_at < now()) return null;
  return r;
}
setInterval(() => run('DELETE FROM sessions WHERE expires_at<?', now()), 3600e3).unref();

/* ---------- live events (server-sent events) ---------- */
const streams = new Map(); // userId -> Set(res)
const calls = new Map();   // room -> { members:Set, allowed:Set|null, group:number|null }
function push(userId, event) {
  const set = streams.get(userId); if (!set) return;
  const data = 'data: ' + JSON.stringify(event) + '\n\n';
  set.forEach(r => r.write(data));
}
const pendingLeave = new Map();
function dropFromCalls(userId) {
  calls.forEach((c, room) => {
    if (!c.members.delete(userId)) return;
    c.members.forEach(m => push(m, { type: 'rtc-leave', room, user: userId }));
    if (!c.members.size && c.group == null) calls.delete(room);
  });
}

/* ---------- relationships ---------- */
const areFriends = (a, b) => !!one("SELECT 1 x FROM friendships WHERE status='accepted' AND ((requester_id=? AND addressee_id=?) OR (requester_id=? AND addressee_id=?))", a, b, b, a);
function relation(me, other) {
  if (me === other) return { self: true };
  const f = one('SELECT requester_id,status FROM friendships WHERE (requester_id=? AND addressee_id=?) OR (requester_id=? AND addressee_id=?)', me, other, other, me);
  let friend = 'none';
  if (f) friend = f.status === 'accepted' ? 'friends' : (f.requester_id === me ? 'pending_out' : 'pending_in');
  return { following: !!one('SELECT 1 x FROM follows WHERE follower_id=? AND followee_id=?', me, other), friend };
}
const dmRoom = (a, b) => 'd:' + Math.min(a, b) + '-' + Math.max(a, b);
function roomAccess(user, room) {
  let m;
  if ((m = /^g:(\d+)$/.exec(room))) {
    const gid = +m[1];
    if (!one('SELECT 1 x FROM group_members WHERE group_id=? AND user_id=?', gid, user.id)) return null;
    return { audience: () => all('SELECT user_id FROM group_members WHERE group_id=?', gid).map(r => r.user_id) };
  }
  if ((m = /^d:(\d+)-(\d+)$/.exec(room))) {
    const a = +m[1], b = +m[2];
    if (a >= b || (user.id !== a && user.id !== b) || !areFriends(a, b)) return null;
    return { audience: () => [a, b] };
  }
  return null;
}

/* ---------- media files ---------- */
function sniff(buf) {
  if (buf.length >= 12 && buf.slice(4, 8).toString('latin1') === 'ftyp') return 'video/mp4';
  if (buf.length >= 4 && buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) return 'video/webm';
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.length >= 8 && buf.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (buf.length >= 12 && buf.slice(0, 4).toString('latin1') === 'RIFF' && buf.slice(8, 12).toString('latin1') === 'WEBP') return 'image/webp';
  return null;
}
function handleUpload(req, res, user) {
  if (req.headers['x-requested-with'] !== 'wraparound') throw new HttpError(403, 'Forbidden');
  const declared = +req.headers['content-length'] || 0;
  if (declared > VIDEO_MAX) throw new HttpError(413, `That file is too large. The limit is ${CFG.maxUploadMb} MB.`);
  limit('up:' + user.id, 40, 3600e3);
  const id = rid(16), tmp = path.join(UPLOADS, 'tmp-' + id), out = fs.createWriteStream(tmp);
  let bytes = 0, mime = null, head = Buffer.alloc(0), failed = false;
  const abort = (code, msg) => {
    if (failed) return; failed = true;
    out.destroy(); fs.rm(tmp, { force: true }, () => {});
    if (!res.headersSent) { res.setHeader('Connection', 'close'); json(res, code, { error: msg }); }
    req.unpipe(); req.resume();
  };
  req.on('data', chunk => {
    if (failed) return;
    bytes += chunk.length;
    if (!mime) {
      head = Buffer.concat([head, chunk]);
      if (head.length >= 12) { mime = sniff(head); if (!mime) return abort(415, 'Use an MP4 or WebM video, or a JPEG, PNG or WebP image.'); }
    }
    const cap = mime && mime.startsWith('image/') ? IMAGE_MAX : VIDEO_MAX;
    if (bytes > cap) return abort(413, `That file is too large. The limit is ${mime && mime.startsWith('image/') ? '8 MB for images' : CFG.maxUploadMb + ' MB for videos'}.`);
    if (!out.write(chunk)) { req.pause(); out.once('drain', () => req.resume()); }
  });
  req.on('end', () => {
    if (failed) return;
    if (!mime) mime = sniff(head);
    if (!mime || bytes < 12) return abort(415, 'Use an MP4 or WebM video, or a JPEG, PNG or WebP image.');
    out.end(() => {
      try {
        fs.renameSync(tmp, path.join(UPLOADS, id));
        run('INSERT INTO media(id,user_id,mime,bytes,created_at) VALUES(?,?,?,?,?)', id, user.id, mime, bytes, now());
        json(res, 200, { id, url: '/media/' + id, mime, bytes });
      } catch (e) { console.error(e); json(res, 500, { error: 'Upload failed' }); }
    });
  });
  req.on('error', () => abort(400, 'Upload interrupted'));
  req.on('aborted', () => abort(400, 'Upload interrupted'));
}
function purgeUser(id) {
  const own = all('SELECT id FROM media WHERE user_id=?', id).map((f) => f.id), groupMedia = [];
  dropFromCalls(id);
  all('SELECT id FROM groups WHERE owner_id=?', id).forEach((g) => {
    const room = 'g:' + g.id;
    all('SELECT media_id FROM messages WHERE room=? AND media_id IS NOT NULL', room).forEach((m) => groupMedia.push(m.media_id));
    run('DELETE FROM messages WHERE room=?', room);
  });
  run('DELETE FROM users WHERE id=?', id);
  own.forEach((f) => fs.rm(path.join(UPLOADS, f), { force: true }, () => {}));
  groupMedia.forEach(removeMedia);
}
async function handleUpdateUpload(req, res, user) {
  if (req.headers['x-requested-with'] !== 'wraparound') throw new HttpError(403, 'Forbidden');
  limit('upd:' + user.id, 20, 3600e3);
  if ((+req.headers['content-length'] || 0) > UPDATER.MAX_UPLOAD) throw new HttpError(413, 'That file is too large for an update package.');
  const chunks = []; let size = 0;
  await new Promise((resolve, reject) => {
    req.on('data', (c) => { size += c.length; if (size > UPDATER.MAX_UPLOAD) { reject(new HttpError(413, 'That file is too large for an update package.')); req.pause(); } else chunks.push(c); });
    req.on('end', resolve); req.on('error', reject); req.on('aborted', () => reject(new HttpError(400, 'Upload interrupted')));
  });
  try { json(res, 200, await UPDATER.check(Buffer.concat(chunks))); }
  catch (e) { json(res, 400, { error: e.message }); }
}
function removeMedia(id) {
  if (!id) return;
  if (one('SELECT 1 x FROM posts WHERE media_id=?', id) || one('SELECT 1 x FROM messages WHERE media_id=?', id) || one('SELECT 1 x FROM users WHERE avatar=?', id)) return;
  run('DELETE FROM media WHERE id=?', id);
  fs.rm(path.join(UPLOADS, id), { force: true }, () => {});
}
function serveMedia(req, res, id) {
  if (!/^[a-f0-9]{32}$/.test(id)) return json(res, 404, { error: 'Not found' });
  const user = sessionUser(req);
  if (!user || user.status !== 'active') return json(res, 401, { error: 'Sign in to view this' });
  const m = one('SELECT mime,bytes FROM media WHERE id=?', id);
  if (!m) return json(res, 404, { error: 'Not found' });
  const file = path.join(UPLOADS, id);
  let start = 0, end = m.bytes - 1, code = 200;
  const range = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
  if (range && (range[1] || range[2])) {
    if (range[1] === '') { start = Math.max(0, m.bytes - +range[2]); }
    else { start = +range[1]; if (range[2]) end = Math.min(end, +range[2]); }
    if (start > end || start >= m.bytes) { res.writeHead(416, { 'Content-Range': `bytes */${m.bytes}` }); return res.end(); }
    code = 206;
  }
  const headers = { 'Content-Type': m.mime, 'Accept-Ranges': 'bytes', 'Content-Length': end - start + 1, 'Cache-Control': 'private, max-age=86400', 'X-Content-Type-Options': 'nosniff' };
  if (code === 206) headers['Content-Range'] = `bytes ${start}-${end}/${m.bytes}`;
  res.writeHead(code, headers);
  if (req.method === 'HEAD') return res.end();
  const s = fs.createReadStream(file, { start, end });
  s.on('error', () => res.destroy());
  res.on('close', () => s.destroy());
  s.pipe(res);
}

/* ---------- routes ---------- */
const routes = [];
function route(method, pat, opts, fn) {
  if (typeof opts === 'function') { fn = opts; opts = {}; }
  const keys = [];
  const re = new RegExp('^' + pat.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  routes.push({ method, re, keys, opts, fn });
}
const need = (cond, code, msg) => { if (!cond) throw new HttpError(code, msg); };
const intParam = v => { const n = +v; if (!Number.isInteger(n) || n < 1) throw bad('Bad id'); return n; };

function postRow(r) {
  return { id: r.id, text: r.text, media: r.media_id ? '/media/' + r.media_id : null, is360: !!r.is360, game: r.game, created_at: r.created_at,
    user: { id: r.uid, handle: r.handle, name: r.name, avatar: r.avatar ? '/media/' + r.avatar : null }, likes: r.likes, comments: r.comments, liked: !!r.liked };
}
const POST_SELECT = `SELECT p.id,p.text,p.media_id,p.is360,p.game,p.created_at,u.id uid,u.handle,u.name,u.avatar,
  (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) likes,
  (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) comments,
  EXISTS(SELECT 1 FROM likes l WHERE l.post_id=p.id AND l.user_id=?) liked
  FROM posts p JOIN users u ON u.id=p.user_id WHERE u.status='active'`;

/* public */
route('GET', '/api/config', { anon: true }, () => ({ siteName: getSetting('site_name', CFG.siteName), headline: getSetting('headline', ''), intro: getSetting('intro', ''), signup: signupMode(), firstRun: !one('SELECT 1 x FROM users LIMIT 1'), maxUploadMb: CFG.maxUploadMb, appVersion: APP_VERSION, startedAt: STARTED_AT, contactEmail: getSetting('contact_email', ''), minAge: +getSetting('min_age', '16'), providers: { google: PROVIDERS.google.enabled(), apple: PROVIDERS.apple.enabled() } }));

route('POST', '/api/register', { anon: true }, ({ req, body, res }) => {
  limit('reg:' + ipOf(req), 10, 600e3);
  const handle = clip(body.handle, 20), name = clip(body.name, 40), email = clip(body.email, 120).toLowerCase(), pw = String(body.password || '');
  need(/^[a-z0-9_]{3,20}$/i.test(handle), 400, 'Username must be 3 to 20 letters, numbers or underscores.');
  need(name.length >= 1, 400, 'Enter your name.');
  need(/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email), 400, 'Enter a valid email address.');
  need(pw.length >= 8 && pw.length <= 200, 400, 'Password must be at least 8 characters.');
  need(body.agree === true, 400, 'You need to accept the Rules, Terms and Privacy Policy to join.');
  const first = !one('SELECT 1 x FROM users LIMIT 1'), isOwner = first || (CFG.adminEmail && email === CFG.adminEmail && !one("SELECT 1 x FROM users WHERE role='admin'"));
  const mode = signupMode(); let inviteCode = null, status = 'active';
  if (!isOwner) {
    need(mode !== 'closed', 403, 'Sign-ups are closed right now.');
    if (mode === 'invite') {
      inviteCode = clip(body.invite, 64).toLowerCase();
      need(inviteCode && one('SELECT 1 x FROM invites WHERE code=? AND used_by IS NULL', inviteCode), 403, 'That invite code is not valid.');
    }
    if (mode === 'approval') status = 'pending';
  }
  need(!one('SELECT 1 x FROM users WHERE handle=?', handle), 409, 'That username is taken.');
  need(!one('SELECT 1 x FROM users WHERE email=?', email), 409, 'An account with that email already exists.');
  const id = tx(() => {
    const r = run('INSERT INTO users(handle,name,email,pass,role,status,created_at,accepted_at,terms_version) VALUES(?,?,?,?,?,?,?,?,?)', handle, name, email, hashPassword(pw), isOwner ? 'admin' : 'user', isOwner ? 'active' : status, now(), now(), policiesStamp());
    if (inviteCode) run('UPDATE invites SET used_by=? WHERE code=?', r.lastInsertRowid, inviteCode);
    return Number(r.lastInsertRowid);
  });
  createSession(res, id);
  return { ok: true };
});
route('POST', '/api/login', { anon: true }, ({ req, body, res }) => {
  limit('login:' + ipOf(req), 15, 600e3);
  const email = clip(body.email, 120).toLowerCase(), u = one('SELECT id,pass FROM users WHERE email=?', email);
  need(u && checkPassword(String(body.password || ''), u.pass), 401, 'Wrong email or password.');
  createSession(res, u.id);
  return { ok: true };
});
route('POST', '/api/logout', { anyStatus: true }, ({ req, res }) => {
  const tok = parseCookies(req.headers.cookie).sid; if (tok) run('DELETE FROM sessions WHERE hash=?', sha(tok));
  clearCookie(res); return { ok: true };
});
route('GET', '/api/me', { anyStatus: true }, ({ user }) => ({
  user: { id: user.id, handle: user.handle, name: user.name, email: user.email, bio: user.bio || '', avatar: user.avatar ? '/media/' + user.avatar : null, role: user.role, status: user.status,
    hasPassword: String(one('SELECT pass FROM users WHERE id=?', user.id).pass).startsWith('s1:'),
    identities: all('SELECT provider,email FROM identities WHERE user_id=? ORDER BY provider', user.id) }
}));
route('POST', '/api/me', ({ user, body }) => {
  const name = clip(body.name, 40), bio = clip(body.bio, 200);
  need(name, 400, 'Enter your name.');
  let avatar = user.avatar;
  if (body.avatar !== undefined) {
    if (body.avatar === null) avatar = null;
    else { const m = one("SELECT id FROM media WHERE id=? AND user_id=? AND mime LIKE 'image/%'", String(body.avatar), user.id); need(m, 400, 'Pick an image you uploaded.'); avatar = m.id; }
  }
  let handle = user.handle;
  if (body.handle !== undefined && clip(body.handle, 20) !== user.handle) {
    handle = clip(body.handle, 20);
    need(/^[a-z0-9_]{3,20}$/i.test(handle), 400, 'Username must be 3 to 20 letters, numbers or underscores.');
    need(!one('SELECT 1 x FROM users WHERE handle=? AND id<>?', handle, user.id), 409, 'That username is taken.');
  }
  run('UPDATE users SET name=?,bio=?,avatar=?,handle=? WHERE id=?', name, bio, avatar, handle, user.id);
  if (user.avatar && user.avatar !== avatar) removeMedia(user.avatar);
  return { ok: true };
});

route('POST', '/api/me/password', ({ req, user, body }) => {
  limit('pw:' + user.id, 10, 600e3);
  const row = one('SELECT pass FROM users WHERE id=?', user.id);
  if (String(row.pass).startsWith('s1:')) need(checkPassword(String(body.current || ''), row.pass), 403, 'Your current password is not right.');
  const next = String(body.next || ''); need(next.length >= 8 && next.length <= 200, 400, 'New password must be at least 8 characters.');
  run('UPDATE users SET pass=? WHERE id=?', hashPassword(next), user.id);
  run('DELETE FROM sessions WHERE user_id=? AND hash<>?', user.id, sha(parseCookies(req.headers.cookie).sid || ''));
  return { ok: true };
});

route('POST', '/api/me/delete', ({ res, user, body }) => {
  need(user.role !== 'admin', 400, "The owner account can't be deleted from here. It would leave the site with no admin.");
  const row = one('SELECT pass FROM users WHERE id=?', user.id), confirm = String(body.confirm || '');
  if (String(row.pass).startsWith('s1:')) need(checkPassword(confirm, row.pass), 403, 'That password is not right.');
  else need(confirm.trim().toLowerCase() === user.handle.toLowerCase(), 403, 'Type your username exactly to confirm.');
  purgeUser(user.id); clearCookie(res);
  return { ok: true };
});
route('GET', '/api/me/export', { raw: true }, ({ res, user }) => {
  const data = {
    exported_at: new Date().toISOString(),
    note: 'Your videos and photos are listed by file id. To get the files themselves, open your posts and save them from there, or ask the site owner.',
    profile: one('SELECT handle,name,email,bio,created_at,accepted_at,terms_version FROM users WHERE id=?', user.id),
    sign_in_methods: all('SELECT provider,email FROM identities WHERE user_id=?', user.id),
    posts: all('SELECT id,text,game,is360,media_id,created_at FROM posts WHERE user_id=? ORDER BY id', user.id),
    comments: all('SELECT post_id,text,created_at FROM comments WHERE user_id=? ORDER BY id', user.id),
    messages_sent: all('SELECT room,text,media_id,created_at FROM messages WHERE user_id=? ORDER BY id', user.id),
    likes: all('SELECT post_id FROM likes WHERE user_id=?', user.id).map((r) => r.post_id),
    following: all('SELECT u.handle FROM follows f JOIN users u ON u.id=f.followee_id WHERE f.follower_id=?', user.id).map((r) => r.handle),
    friends: all("SELECT u.handle FROM friendships f JOIN users u ON u.id=CASE WHEN f.requester_id=? THEN f.addressee_id ELSE f.requester_id END WHERE f.status='accepted' AND (f.requester_id=? OR f.addressee_id=?)", user.id, user.id, user.id).map((r) => r.handle),
    groups: all('SELECT g.id,g.name FROM group_members m JOIN groups g ON g.id=m.group_id WHERE m.user_id=?', user.id)
  };
  const body = JSON.stringify(data, null, 2);
  res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': 'attachment; filename="my-data.json"', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
});
route('POST', '/api/me/identities/:provider/disconnect', ({ user, params }) => {
  const prov = params.provider, hasPw = String(one('SELECT pass FROM users WHERE id=?', user.id).pass).startsWith('s1:');
  const n = one('SELECT COUNT(*) n FROM identities WHERE user_id=?', user.id).n;
  need(one('SELECT 1 x FROM identities WHERE user_id=? AND provider=?', user.id, prov), 404, 'Not connected');
  need(hasPw || n > 1, 400, 'Set a password first, or you would be locked out of your account.');
  run('DELETE FROM identities WHERE user_id=? AND provider=?', user.id, prov);
  return { ok: true };
});

/* feed and posts */
route('GET', '/api/feed', ({ user, query }) => {
  const following = query.get('tab') === 'following', before = +query.get('before') || 0;
  let sql = POST_SELECT, args = [user.id];
  if (following) { sql += ' AND (p.user_id=? OR p.user_id IN (SELECT followee_id FROM follows WHERE follower_id=?))'; args.push(user.id, user.id); }
  if (before) { sql += ' AND p.id<?'; args.push(before); }
  sql += ' ORDER BY p.id DESC LIMIT 21';
  const rows = all(sql, ...args), more = rows.length > 20;
  return { posts: rows.slice(0, 20).map(postRow), next: more ? rows[19].id : null };
});
route('POST', '/api/posts', ({ user, body }) => {
  limit('post:' + user.id, 30, 3600e3);
  const text = clip(body.text, 500), game = clip(body.game, 60);
  let media = null;
  if (body.media) { const m = one("SELECT id FROM media WHERE id=? AND user_id=? AND mime LIKE 'video/%'", String(body.media), user.id); need(m, 400, 'Upload the video first.'); media = m.id; }
  need(text || media, 400, 'Add a caption or a video.');
  const r = run('INSERT INTO posts(user_id,text,media_id,is360,game,created_at) VALUES(?,?,?,?,?,?)', user.id, text, media, body.is360 && media ? 1 : 0, game, now());
  return { id: Number(r.lastInsertRowid) };
});
route('DELETE', '/api/posts/:id', ({ user, params }) => {
  const p = one('SELECT id,user_id,media_id FROM posts WHERE id=?', intParam(params.id));
  need(p, 404, 'Not found'); need(p.user_id === user.id || user.role === 'admin', 403, 'Not allowed');
  run('DELETE FROM posts WHERE id=?', p.id); removeMedia(p.media_id);
  return { ok: true };
});
route('POST', '/api/posts/:id/like', ({ user, params }) => {
  const id = intParam(params.id); need(one('SELECT 1 x FROM posts WHERE id=?', id), 404, 'Not found');
  const had = one('SELECT 1 x FROM likes WHERE user_id=? AND post_id=?', user.id, id);
  if (had) run('DELETE FROM likes WHERE user_id=? AND post_id=?', user.id, id); else run('INSERT INTO likes(user_id,post_id) VALUES(?,?)', user.id, id);
  return { liked: !had, likes: one('SELECT COUNT(*) n FROM likes WHERE post_id=?', id).n };
});
route('GET', '/api/posts/:id/comments', ({ params }) => ({
  comments: all(`SELECT c.id,c.text,c.created_at,${userCols} FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? AND u.status='active' ORDER BY c.id ASC LIMIT 200`, intParam(params.id))
    .map(r => ({ id: r.id, text: r.text, created_at: r.created_at, user: pubUser(r) }))
}));
route('POST', '/api/posts/:id/comments', ({ user, params, body }) => {
  limit('cm:' + user.id, 60, 600e3);
  const id = intParam(params.id), text = clip(body.text, 300);
  need(text, 400, 'Write something first.'); need(one('SELECT 1 x FROM posts WHERE id=?', id), 404, 'Not found');
  const r = run('INSERT INTO comments(post_id,user_id,text,created_at) VALUES(?,?,?,?)', id, user.id, text, now());
  return { comment: { id: Number(r.lastInsertRowid), text, created_at: now(), user: pubUser(user) } };
});
route('POST', '/api/posts/:id/report', ({ user, params, body }) => {
  limit('rep:' + user.id, 20, 3600e3);
  const id = intParam(params.id), reason = clip(body.reason, 200); need(reason, 400, 'Say what is wrong.'); need(one('SELECT 1 x FROM posts WHERE id=?', id), 404, 'Not found');
  run('INSERT INTO reports(post_id,reporter_id,reason,created_at) VALUES(?,?,?,?)', id, user.id, reason, now());
  return { ok: true };
});

/* people */
function withRelation(me, rows) { return rows.map(r => ({ ...pubUser(r), ...relation(me.id, r.id) })); }
route('GET', '/api/users', ({ user, query }) => {
  const q = clip(query.get('q'), 40).replace(/[%_]/g, '');
  const rows = q
    ? all(`SELECT ${userCols} FROM users u WHERE u.status='active' AND u.id<>? AND (u.handle LIKE ? OR u.name LIKE ?) ORDER BY u.name LIMIT 30`, user.id, q + '%', '%' + q + '%')
    : all(`SELECT ${userCols} FROM users u WHERE u.status='active' AND u.id<>? ORDER BY u.id DESC LIMIT 30`, user.id);
  return { users: withRelation(user, rows) };
});
route('GET', '/api/users/:handle', ({ user, params, query }) => {
  const u = one(`SELECT ${userCols},u.created_at FROM users u WHERE u.handle=? AND u.status='active'`, params.handle);
  need(u, 404, 'No such person');
  const before = +query.get('before') || 0;
  const rows = all(POST_SELECT + ' AND p.user_id=?' + (before ? ' AND p.id<?' : '') + ' ORDER BY p.id DESC LIMIT 21', ...[user.id, u.id].concat(before ? [before] : []));
  return {
    user: { ...pubUser(u), created_at: u.created_at, ...relation(user.id, u.id) },
    counts: { posts: one('SELECT COUNT(*) n FROM posts WHERE user_id=?', u.id).n, followers: one('SELECT COUNT(*) n FROM follows WHERE followee_id=?', u.id).n, following: one('SELECT COUNT(*) n FROM follows WHERE follower_id=?', u.id).n },
    posts: rows.slice(0, 20).map(postRow), next: rows.length > 20 ? rows[19].id : null
  };
});
route('POST', '/api/follow/:id', ({ user, params }) => {
  const id = intParam(params.id); need(id !== user.id, 400, "You can't follow yourself."); need(one("SELECT 1 x FROM users WHERE id=? AND status='active'", id), 404, 'No such person');
  const had = one('SELECT 1 x FROM follows WHERE follower_id=? AND followee_id=?', user.id, id);
  if (had) run('DELETE FROM follows WHERE follower_id=? AND followee_id=?', user.id, id); else run('INSERT INTO follows(follower_id,followee_id) VALUES(?,?)', user.id, id);
  return { following: !had };
});
route('GET', '/api/friends', ({ user }) => {
  const friends = all(`SELECT ${userCols} FROM friendships f JOIN users u ON u.id=CASE WHEN f.requester_id=? THEN f.addressee_id ELSE f.requester_id END WHERE f.status='accepted' AND (f.requester_id=? OR f.addressee_id=?) AND u.status='active' ORDER BY u.name`, user.id, user.id, user.id);
  const incoming = all(`SELECT ${userCols} FROM friendships f JOIN users u ON u.id=f.requester_id WHERE f.addressee_id=? AND f.status='pending' AND u.status='active'`, user.id);
  const outgoing = all(`SELECT ${userCols} FROM friendships f JOIN users u ON u.id=f.addressee_id WHERE f.requester_id=? AND f.status='pending' AND u.status='active'`, user.id);
  return { friends: friends.map(r => ({ ...pubUser(r), room: dmRoom(user.id, r.id) })), incoming: incoming.map(pubUser), outgoing: outgoing.map(pubUser) };
});
route('POST', '/api/friends/:id', ({ user, params }) => {
  const id = intParam(params.id); need(id !== user.id, 400, "You can't friend yourself."); need(one("SELECT 1 x FROM users WHERE id=? AND status='active'", id), 404, 'No such person');
  const rev = one("SELECT status FROM friendships WHERE requester_id=? AND addressee_id=?", id, user.id);
  if (rev) { run("UPDATE friendships SET status='accepted' WHERE requester_id=? AND addressee_id=?", id, user.id); push(id, { type: 'friend' }); return { friend: 'friends' }; }
  if (!one('SELECT 1 x FROM friendships WHERE requester_id=? AND addressee_id=?', user.id, id)) { run('INSERT INTO friendships(requester_id,addressee_id,status,created_at) VALUES(?,?,?,?)', user.id, id, 'pending', now()); push(id, { type: 'friend' }); }
  return { friend: relation(user.id, id).friend };
});
route('DELETE', '/api/friends/:id', ({ user, params }) => {
  const id = intParam(params.id);
  run('DELETE FROM friendships WHERE (requester_id=? AND addressee_id=?) OR (requester_id=? AND addressee_id=?)', user.id, id, id, user.id);
  return { friend: 'none' };
});

/* groups */
route('GET', '/api/groups', ({ user }) => ({
  groups: all(`SELECT g.id,g.name,g.description,g.owner_id,(SELECT COUNT(*) FROM group_members m WHERE m.group_id=g.id) members,EXISTS(SELECT 1 FROM group_members m WHERE m.group_id=g.id AND m.user_id=?) member FROM groups g ORDER BY g.id DESC LIMIT 100`, user.id)
    .map(g => ({ id: g.id, name: g.name, description: g.description, members: g.members, member: !!g.member, mine: g.owner_id === user.id, room: 'g:' + g.id }))
}));
route('POST', '/api/groups', ({ user, body }) => {
  limit('grp:' + user.id, 10, 3600e3);
  const name = clip(body.name, 60), description = clip(body.description, 200); need(name, 400, 'Give the group a name.');
  const id = tx(() => { const r = run('INSERT INTO groups(name,description,owner_id,created_at) VALUES(?,?,?,?)', name, description, user.id, now()); run('INSERT INTO group_members(group_id,user_id,joined_at) VALUES(?,?,?)', r.lastInsertRowid, user.id, now()); return Number(r.lastInsertRowid); });
  return { id };
});
route('GET', '/api/groups/:id', ({ user, params }) => {
  const id = intParam(params.id), g = one('SELECT id,name,description,owner_id FROM groups WHERE id=?', id); need(g, 404, 'Not found');
  const members = all(`SELECT ${userCols} FROM group_members m JOIN users u ON u.id=m.user_id WHERE m.group_id=? AND u.status='active' ORDER BY m.joined_at LIMIT 100`, id).map(pubUser);
  return { group: { id: g.id, name: g.name, description: g.description, room: 'g:' + g.id, mine: g.owner_id === user.id, member: members.some(m => m.id === user.id) }, members };
});
route('POST', '/api/groups/:id/join', ({ user, params }) => { const id = intParam(params.id); need(one('SELECT 1 x FROM groups WHERE id=?', id), 404, 'Not found'); run('INSERT OR IGNORE INTO group_members(group_id,user_id,joined_at) VALUES(?,?,?)', id, user.id, now()); return { member: true }; });
route('POST', '/api/groups/:id/leave', ({ user, params }) => { run('DELETE FROM group_members WHERE group_id=? AND user_id=?', intParam(params.id), user.id); return { member: false }; });
route('DELETE', '/api/groups/:id', ({ user, params }) => {
  const id = intParam(params.id), g = one('SELECT owner_id FROM groups WHERE id=?', id); need(g, 404, 'Not found'); need(g.owner_id === user.id || user.role === 'admin', 403, 'Not allowed');
  const media = all('SELECT media_id FROM messages WHERE room=? AND media_id IS NOT NULL', 'g:' + id);
  run('DELETE FROM messages WHERE room=?', 'g:' + id); run('DELETE FROM groups WHERE id=?', id); media.forEach(m => removeMedia(m.media_id));
  return { ok: true };
});

/* chat */
const msgRow = r => ({ id: r.id, room: r.room, text: r.text, media: r.media_id ? '/media/' + r.media_id : null, created_at: r.created_at, user: pubUser(r) });
route('GET', '/api/chat/:room', ({ user, params, query }) => {
  const room = decodeURIComponent(params.room); need(roomAccess(user, room), 403, 'No access to this chat');
  const before = +query.get('before') || 0;
  const rows = all(`SELECT m.id,m.room,m.text,m.media_id,m.created_at,${userCols} FROM messages m JOIN users u ON u.id=m.user_id WHERE m.room=? ${before ? 'AND m.id<?' : ''} ORDER BY m.id DESC LIMIT 60`, ...[room].concat(before ? [before] : []));
  return { messages: rows.reverse().map(msgRow) };
});
route('POST', '/api/chat/:room', ({ user, params, body }) => {
  limit('msg:' + user.id, 60, 60e3);
  const room = decodeURIComponent(params.room), acc = roomAccess(user, room); need(acc, 403, 'No access to this chat');
  const text = clip(body.text, 1000); let media = null;
  if (body.media) { const m = one("SELECT id FROM media WHERE id=? AND user_id=?", String(body.media), user.id); need(m, 400, 'Upload the file first.'); media = m.id; }
  need(text || media, 400, 'Write something first.');
  const r = run('INSERT INTO messages(room,user_id,text,media_id,created_at) VALUES(?,?,?,?,?)', room, user.id, text, media, now());
  const msg = { id: Number(r.lastInsertRowid), room, text, media: media ? '/media/' + media : null, created_at: now(), user: pubUser(user) };
  acc.audience().forEach(uid => push(uid, { type: 'chat', message: msg }));
  return { message: msg };
});

/* live events */
route('GET', '/api/events', { raw: true }, ({ req, res, user }) => {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.write('retry: 3000\n\n');
  let set = streams.get(user.id); if (!set) streams.set(user.id, set = new Set());
  set.add(res);
  clearTimeout(pendingLeave.get(user.id));
  const beat = setInterval(() => res.write(': hb\n\n'), 25000);
  req.on('close', () => {
    clearInterval(beat); set.delete(res);
    if (!set.size) { streams.delete(user.id); pendingLeave.set(user.id, setTimeout(() => { if (!streams.has(user.id)) dropFromCalls(user.id); }, 20000)); }
  });
});

/* calls: signalling for WebRTC. Audio and video go directly between browsers. */
route('GET', '/api/ice', () => {
  const servers = [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }];
  if (CFG.turn.url) servers.push({ urls: CFG.turn.url.split(','), username: CFG.turn.user, credential: CFG.turn.pass });
  return { iceServers: servers };
});
route('POST', '/api/calls', ({ user, body }) => {
  const to = intParam(body.to); need(areFriends(user.id, to), 403, 'You can only call friends.');
  const room = 'c' + rid(8); calls.set(room, { members: new Set(), allowed: new Set([user.id, to]), group: null });
  push(to, { type: 'call-invite', room, from: pubUser(user), title: null });
  return { room };
});
route('POST', '/api/calls/group/:id', ({ user, params }) => {
  const gid = intParam(params.id), g = one('SELECT name FROM groups WHERE id=?', gid); need(g && one('SELECT 1 x FROM group_members WHERE group_id=? AND user_id=?', gid, user.id), 403, 'Join the group first.');
  const room = 'g' + gid; if (!calls.has(room)) calls.set(room, { members: new Set(), allowed: null, group: gid });
  const c = calls.get(room);
  if (!c.members.size) all('SELECT user_id FROM group_members WHERE group_id=?', gid).forEach(m => { if (m.user_id !== user.id) push(m.user_id, { type: 'call-invite', room, from: pubUser(user), title: g.name }); });
  return { room };
});
function callAccess(user, room) {
  const c = calls.get(room); need(c, 404, 'That call has ended.');
  if (c.group != null) need(one('SELECT 1 x FROM group_members WHERE group_id=? AND user_id=?', c.group, user.id), 403, 'Not allowed');
  else need(c.allowed.has(user.id), 403, 'Not allowed');
  return c;
}
route('POST', '/api/calls/:room/join', ({ user, params }) => {
  const room = params.room, c = callAccess(user, room);
  need(c.members.size < 6 || c.members.has(user.id), 409, 'This call is full (6 people).');
  const peers = [...c.members].filter(m => m !== user.id);
  c.members.add(user.id);
  const people = all(`SELECT ${userCols} FROM users u WHERE u.id IN (${[user.id, ...peers].map(() => '?').join(',')})`, user.id, ...peers).map(pubUser);
  peers.forEach(m => push(m, { type: 'rtc-join', room, user: pubUser(user) }));
  return { peers: people.filter(p => p.id !== user.id) };
});
route('POST', '/api/calls/:room/leave', ({ user, params }) => {
  const room = params.room, c = calls.get(room); if (!c) return { ok: true };
  if (c.members.delete(user.id)) c.members.forEach(m => push(m, { type: 'rtc-leave', room, user: user.id }));
  if (!c.members.size && c.group == null) calls.delete(room);
  return { ok: true };
});
route('POST', '/api/rtc', ({ user, body }) => {
  const room = String(body.room || ''), to = intParam(body.to), c = calls.get(room);
  need(c && c.members.has(user.id) && c.members.has(to), 403, 'Not in this call');
  const data = JSON.stringify(body.data || {}); need(data.length < 20000, 413, 'Too large');
  push(to, { type: 'rtc', room, from: user.id, data: body.data });
  return { ok: true };
});

/* admin */
const admin = { admin: true };
route('GET', '/api/admin/stats', admin, () => {
  const n = sql => one(sql).n;
  return {
    users: n("SELECT COUNT(*) n FROM users"), pending: n("SELECT COUNT(*) n FROM users WHERE status='pending'"), banned: n("SELECT COUNT(*) n FROM users WHERE status='banned'"),
    posts: n('SELECT COUNT(*) n FROM posts'), videos: n('SELECT COUNT(*) n FROM posts WHERE media_id IS NOT NULL'), comments: n('SELECT COUNT(*) n FROM comments'),
    messages: n('SELECT COUNT(*) n FROM messages'), groups: n('SELECT COUNT(*) n FROM groups'), reports: n('SELECT COUNT(*) n FROM reports WHERE resolved=0'),
    storage: one('SELECT COALESCE(SUM(bytes),0) n FROM media').n, files: n('SELECT COUNT(*) n FROM media'), online: streams.size, signup: signupMode()
  };
});
route('GET', '/api/admin/users', admin, () => ({
  users: all(`SELECT u.id,u.handle,u.name,u.email,u.role,u.status,u.created_at,u.avatar,(SELECT COUNT(*) FROM posts p WHERE p.user_id=u.id) posts FROM users u ORDER BY u.id DESC LIMIT 500`).map(r => ({ ...r, avatar: r.avatar ? '/media/' + r.avatar : null }))
}));
route('POST', '/api/admin/users/:id', admin, ({ user, params, body }) => {
  const id = intParam(params.id); need(id !== user.id, 400, "You can't change your own account here."); const t = one('SELECT id FROM users WHERE id=?', id); need(t, 404, 'Not found');
  if (body.status !== undefined) { need(['active', 'pending', 'banned'].includes(body.status), 400, 'Bad status'); run('UPDATE users SET status=? WHERE id=?', body.status, id); if (body.status === 'banned') { run('DELETE FROM sessions WHERE user_id=?', id); dropFromCalls(id); } }
  need(body.role === undefined, 400, 'Admin rights stay with the owner and cannot be given to anyone else.');
  if (body.password !== undefined) { need(String(body.password).length >= 8, 400, 'Password must be at least 8 characters.'); run('UPDATE users SET pass=? WHERE id=?', hashPassword(String(body.password)), id); run('DELETE FROM sessions WHERE user_id=?', id); }
  return { ok: true };
});
route('DELETE', '/api/admin/users/:id', admin, ({ user, params }) => {
  const id = intParam(params.id); need(id !== user.id, 400, "You can't delete your own account."); need(one('SELECT 1 x FROM users WHERE id=?', id), 404, 'Not found');
  purgeUser(id);
  return { ok: true };
});
route('GET', '/api/admin/reports', admin, () => ({
  reports: all(`SELECT r.id,r.reason,r.created_at,r.post_id,p.text,p.media_id,pu.handle author,pu.id author_id,ru.handle reporter FROM reports r JOIN posts p ON p.id=r.post_id JOIN users pu ON pu.id=p.user_id JOIN users ru ON ru.id=r.reporter_id WHERE r.resolved=0 ORDER BY r.id DESC LIMIT 100`)
}));
route('POST', '/api/admin/reports/:id/resolve', admin, ({ params }) => { run('UPDATE reports SET resolved=1 WHERE id=?', intParam(params.id)); return { ok: true }; });
route('GET', '/api/admin/posts', admin, () => ({ posts: all(POST_SELECT.replace("WHERE u.status='active'", 'WHERE 1=1') + ' ORDER BY p.id DESC LIMIT 100', 0).map(postRow) }));
route('GET', '/api/admin/invites', admin, () => ({
  invites: all('SELECT i.code,i.note,i.created_at,i.used_by,u.handle used_by_handle FROM invites i LEFT JOIN users u ON u.id=i.used_by ORDER BY i.created_at DESC LIMIT 200')
}));
route('POST', '/api/admin/invites', admin, ({ user, body }) => {
  const n = Math.min(20, Math.max(1, +body.count || 1)), note = clip(body.note, 80), codes = [];
  for (let i = 0; i < n; i++) { const code = rid(4); run('INSERT INTO invites(code,created_by,note,created_at) VALUES(?,?,?,?)', code, user.id, note, now()); codes.push(code); }
  return { codes };
});
route('DELETE', '/api/admin/invites/:code', admin, ({ params }) => { run('DELETE FROM invites WHERE code=? AND used_by IS NULL', params.code); return { ok: true }; });
route('GET', '/api/admin/site', admin, () => ({ siteName: getSetting('site_name', CFG.siteName), headline: getSetting('headline', ''), intro: getSetting('intro', ''), domain: CFG.publicUrl }));
route('POST', '/api/admin/site', admin, ({ body }) => {
  const siteName = clip(body.siteName, 40), headline = clip(body.headline, 120), intro = clip(body.intro, 400);
  need(siteName, 400, 'The site needs a name.');
  setSetting('site_name', siteName); setSetting('headline', headline); setSetting('intro', intro);
  return { ok: true };
});
function confirmOwner(user, confirm) {
  const row = one('SELECT pass FROM users WHERE id=?', user.id), c = String(confirm || '');
  if (String(row.pass).startsWith('s1:')) need(checkPassword(c, row.pass), 403, 'That password is not right.');
  else need(c.trim().toLowerCase() === user.handle.toLowerCase(), 403, 'Type your username exactly to confirm.');
}
const restartSoon = () => setTimeout(() => { try { server.close(); } catch (e) { /* ignore */ } process.exit(75); }, 500);
route('GET', '/api/admin/update', admin, () => ({ ...UPDATER.info(), maxUploadMb: Math.round(UPDATER.MAX_UPLOAD / 1048576) }));
route('POST', '/api/admin/update/apply', admin, ({ user, body }) => {
  need(UPDATER.supervised, 400, 'Updates need the site to be started the normal way (node server.js, the Start file, or Docker).');
  confirmOwner(user, body.confirm);
  let r; try { r = UPDATER.apply(String(body.id || '')); } catch (e) { throw new HttpError(400, e.message); }
  restartSoon(); return { ok: true, version: r.version };
});
route('POST', '/api/admin/update/rollback', admin, ({ user, body }) => {
  need(UPDATER.supervised, 400, 'Updates need the site to be started the normal way (node server.js, the Start file, or Docker).');
  confirmOwner(user, body.confirm);
  let r; try { r = UPDATER.rollback(); } catch (e) { throw new HttpError(400, e.message); }
  restartSoon(); return { ok: true, version: r.version };
});
route('POST', '/api/admin/restart', admin, ({ user, body }) => {
  need(UPDATER.supervised, 400, 'Restarting needs the site to be started the normal way (node server.js, the Start file, or Docker).');
  confirmOwner(user, body.confirm); restartSoon(); return { ok: true };
});
route('GET', '/api/admin/backup', { admin: true, raw: true }, ({ res }) => {
  const file = backupDb('download'), size = fs.statSync(file).size;
  res.writeHead(200, { 'Content-Type': 'application/vnd.sqlite3', 'Content-Disposition': `attachment; filename="wraparound-backup-${new Date().toISOString().slice(0, 10)}.sqlite"`, 'Content-Length': size, 'Cache-Control': 'no-store' });
  fs.createReadStream(file).pipe(res);
});
const emailOk = (e) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e);
route('GET', '/api/admin/policies', admin, () => ({
  contactEmail: getSetting('contact_email', ''), operator: getSetting('operator', ''), minAge: +getSetting('min_age', '16'), updated: +policiesStamp(),
  rules: policyText('rules'), terms: policyText('terms'), privacy: policyText('privacy'),
  custom: { rules: !!getSetting('policy_rules', ''), terms: !!getSetting('policy_terms', ''), privacy: !!getSetting('policy_privacy', '') }
}));
route('POST', '/api/admin/policies', admin, ({ body }) => {
  const contact = clip(body.contactEmail, 120), operator = clip(body.operator, 120), age = Math.round(+body.minAge);
  need(!contact || emailOk(contact), 400, 'That contact email does not look right.');
  need(age >= 13 && age <= 21, 400, 'The minimum age must be between 13 and 21.');
  let changed = false;
  for (const k of ['rules', 'terms', 'privacy']) {
    if (body[k] === undefined) continue;
    const t = String(body[k]).replace(/\r/g, '').trim(); need(t.length <= 30000, 400, 'That text is too long.');
    const next = !t || t === POL.DEFAULTS[k].trim() ? '' : t;
    if (next !== getSetting('policy_' + k, '')) { setSetting('policy_' + k, next); changed = true; }
  }
  if (contact !== getSetting('contact_email', '') || operator !== getSetting('operator', '') || String(age) !== getSetting('min_age', '16')) changed = true;
  setSetting('contact_email', contact); setSetting('operator', operator); setSetting('min_age', String(age));
  if (changed) setSetting('policies_updated', String(now()));
  return { ok: true };
});
route('POST', '/api/admin/policies/reset', admin, ({ body }) => {
  need(['rules', 'terms', 'privacy'].includes(body.which), 400, 'Unknown page'); setSetting('policy_' + body.which, ''); setSetting('policies_updated', String(now()));
  return { text: POL.DEFAULTS[body.which] };
});
route('GET', '/api/admin/launch', admin, () => {
  const v = policyVars(), contact = getSetting('contact_email', '');
  const unfilled = ['rules', 'terms', 'privacy'].some((k) => POL.hasPlaceholders(POL.fill(policyText(k), v)));
  const items = [
    { id: 'contact', required: true, ok: emailOk(contact), label: 'A contact email is set', hint: 'People need it to report problems, ask for takedowns and make privacy requests. Add it under Policies.' },
    { id: 'policies', required: true, ok: !unfilled, label: 'Nothing is left to fill in on the Rules, Terms and Privacy pages', hint: 'Look for highlighted [parts in brackets] on those pages (the governing-law line in the Terms has one) and replace them under Policies.' },
    { id: 'https', required: true, ok: /^https:\/\//.test(CFG.publicUrl), label: 'Your web address is set and uses https', hint: 'Run scripts/set-domain.js, or set PUBLIC_URL. Calls and Sign in with Apple need https.' },
    { id: 'operator', required: false, ok: !!getSetting('operator', ''), label: 'Your name or company name is in the Terms and Privacy pages', hint: 'Add it under Policies. Until then they say "the owner of ' + siteName() + '".' },
    { id: 'signup', required: false, ok: signupMode() !== 'open', label: 'Sign-ups are invite-only, approval or closed', hint: 'Open sign-ups need much more moderation. Invite-only keeps it to people you know.' },
    { id: 'turn', required: false, ok: !!CFG.turn.url, label: 'A call relay (TURN server) is set up', hint: 'Optional. Without one, calls fail on some office, school and mobile networks.' }
  ];
  return { items, ready: items.filter((i) => i.required).every((i) => i.ok) };
});
route('POST', '/api/admin/settings', admin, ({ body }) => {
  if (body.signup !== undefined) { need(['open', 'approval', 'invite', 'closed'].includes(body.signup), 400, 'Bad mode'); setSetting('signup_mode', body.signup); }
  return { signup: signupMode() };
});

/* ---------- sign in with Google / Apple (OpenID Connect, authorization code flow) ---------- */
const SECRET_FILE = path.join(CFG.dataDir, 'secret.key');
if (!fs.existsSync(SECRET_FILE)) fs.writeFileSync(SECRET_FILE, rid(32), { mode: 0o600 });
const SECRET = fs.readFileSync(SECRET_FILE, 'utf8').trim();
const hmac = d => crypto.createHmac('sha256', SECRET).update(d).digest('base64url');
const signed = obj => { const p = Buffer.from(JSON.stringify(obj)).toString('base64url'); return p + '.' + hmac(p); };
function readSigned(str) {
  const [p, sig] = String(str || '').split('.'); if (!p || !sig) return null;
  const a = Buffer.from(sig), b = Buffer.from(hmac(p)); if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try { return JSON.parse(Buffer.from(p, 'base64url').toString('utf8')); } catch (e) { return null; }
}
const env = process.env;
function applePrivateKey() {
  if (env.APPLE_PRIVATE_KEY_FILE) { try { return fs.readFileSync(env.APPLE_PRIVATE_KEY_FILE, 'utf8'); } catch (e) { return ''; } }
  return (env.APPLE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
}
let appleCache = { jwt: '', exp: 0 };
function appleClientSecret() {
  if (appleCache.exp > now() + 30000) return appleCache.jwt;
  const t = Math.floor(now() / 1000), enc = o => Buffer.from(JSON.stringify(o)).toString('base64url');
  const data = enc({ alg: 'ES256', kid: env.APPLE_KEY_ID }) + '.' + enc({ iss: env.APPLE_TEAM_ID, iat: t, exp: t + 600, aud: 'https://appleid.apple.com', sub: env.APPLE_CLIENT_ID });
  const sig = crypto.sign('sha256', Buffer.from(data), { key: applePrivateKey(), dsaEncoding: 'ieee-p1363' }).toString('base64url');
  appleCache = { jwt: data + '.' + sig, exp: now() + 540000 };
  return appleCache.jwt;
}
const PROVIDERS = {
  google: {
    label: 'Google', id: () => env.GOOGLE_CLIENT_ID || '', secret: () => env.GOOGLE_CLIENT_SECRET || '',
    enabled: () => !!(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET),
    auth: env.GOOGLE_AUTH_URL || 'https://accounts.google.com/o/oauth2/v2/auth', token: env.GOOGLE_TOKEN_URL || 'https://oauth2.googleapis.com/token', jwks: env.GOOGLE_JWKS_URL || 'https://www.googleapis.com/oauth2/v3/certs',
    issuers: env.GOOGLE_ISSUER ? [env.GOOGLE_ISSUER] : ['https://accounts.google.com', 'accounts.google.com'], scope: 'openid email profile', extra: { prompt: 'select_account' }
  },
  apple: {
    label: 'Apple', id: () => env.APPLE_CLIENT_ID || '', secret: appleClientSecret,
    enabled: () => !!(env.APPLE_CLIENT_ID && env.APPLE_TEAM_ID && env.APPLE_KEY_ID && applePrivateKey()),
    auth: env.APPLE_AUTH_URL || 'https://appleid.apple.com/auth/authorize', token: env.APPLE_TOKEN_URL || 'https://appleid.apple.com/auth/token', jwks: env.APPLE_JWKS_URL || 'https://appleid.apple.com/auth/keys',
    issuers: env.APPLE_ISSUER ? [env.APPLE_ISSUER] : ['https://appleid.apple.com'], scope: 'name email', extra: { response_mode: 'form_post' }
  }
};
const jwksCache = new Map();
async function getJwks(url, force) {
  const c = jwksCache.get(url);
  if (c && !force && c.exp > now()) return c.keys;
  const r = await fetch(url, { signal: AbortSignal.timeout(10000) }); if (!r.ok) throw new Error('Could not load the provider keys');
  const keys = (await r.json()).keys || []; jwksCache.set(url, { keys, exp: now() + 3600e3 }); return keys;
}
async function verifyIdToken(P, token, nonce) {
  const parts = String(token || '').split('.'); if (parts.length !== 3) throw new Error('Bad token');
  const header = JSON.parse(Buffer.from(parts[0], 'base64url').toString()), claims = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
  if (header.alg !== 'RS256') throw new Error('Unexpected token type');
  let jwk = (await getJwks(P.jwks)).find(k => k.kid === header.kid);
  if (!jwk) jwk = (await getJwks(P.jwks, true)).find(k => k.kid === header.kid);
  if (!jwk) throw new Error('Unknown signing key');
  const okSig = crypto.verify('RSA-SHA256', Buffer.from(parts[0] + '.' + parts[1]), crypto.createPublicKey({ key: jwk, format: 'jwk' }), Buffer.from(parts[2], 'base64url'));
  if (!okSig) throw new Error('Bad token signature');
  const aud = Array.isArray(claims.aud) ? claims.aud : [claims.aud];
  if (!P.issuers.includes(claims.iss) || !aud.includes(P.id()) || !(claims.exp * 1000 > now() - 60000) || claims.nonce !== nonce || !claims.sub) throw new Error('Token was not meant for this site');
  return claims;
}
const baseUrl = req => CFG.publicUrl || 'http://' + req.headers.host;
const redirect = (res, to) => { res.writeHead(303, { Location: to, 'Cache-Control': 'no-store' }); res.end(); };
const authFail = (res, msg) => redirect(res, '/?auth_error=' + encodeURIComponent(msg));
const oaCookie = (v, maxAge) => `oa=${v}; Path=/auth; HttpOnly; Max-Age=${maxAge}; SameSite=${CFG.secureCookie ? 'None; Secure' : 'Lax'}`;
function uniqueHandle(seed) {
  let base = String(seed || '').toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 14);
  if (base.length < 3) base = (base + 'member').slice(0, 10);
  let h = base; while (one('SELECT 1 x FROM users WHERE handle=?', h)) h = base + Math.floor(100 + Math.random() * 99900);
  return h.slice(0, 20);
}
async function readForm(req) {
  const chunks = []; let size = 0;
  for await (const c of req) { size += c.length; if (size > 100 * 1024) throw new Error('Too large'); chunks.push(c); }
  return new URLSearchParams(Buffer.concat(chunks).toString('utf8'));
}
async function authRoute(req, res, url) {
  const m = /^\/auth\/(google|apple)\/(start|callback)\/?$/.exec(url.pathname);
  if (!m) return authFail(res, 'Unknown sign-in address.');
  const provider = m[1], P = PROVIDERS[provider];
  try {
    if (!P.enabled()) return authFail(res, P.label + ' sign-in is not set up on this site.');
    const redirectUri = baseUrl(req) + '/auth/' + provider + '/callback';
    if (m[2] === 'start') {
      if (req.method !== 'GET') return authFail(res, 'Bad request.');
      limit('oauth:' + ipOf(req), 30, 600e3);
      let link = 0;
      if (url.searchParams.get('link')) { const u = sessionUser(req); if (!u || u.status !== 'active') return authFail(res, 'Sign in first, then connect ' + P.label + '.'); link = u.id; }
      const state = rid(16), nonce = rid(16);
      const ctx = { s: state, n: nonce, p: provider, i: clip(url.searchParams.get('invite'), 64).toLowerCase(), l: link, a: url.searchParams.get('agree') === '1' ? 1 : 0, t: now() + 600e3 };
      const q = new URLSearchParams({ client_id: P.id(), redirect_uri: redirectUri, response_type: 'code', scope: P.scope, state, nonce, ...P.extra });
      res.setHeader('Set-Cookie', oaCookie(signed(ctx), 600));
      return redirect(res, P.auth + (P.auth.includes('?') ? '&' : '?') + q);
    }
    // callback: Google sends a GET, Apple sends a form POST
    const params = req.method === 'POST' ? await readForm(req) : url.searchParams;
    const ctx = readSigned(parseCookies(req.headers.cookie).oa);
    res.setHeader('Set-Cookie', oaCookie('', 0));
    if (params.get('error')) return authFail(res, params.get('error') === 'access_denied' || params.get('error') === 'user_cancelled_authorize' ? 'Sign-in was cancelled.' : P.label + ' could not sign you in.');
    const given = String(params.get('state') || '');
    if (!ctx || ctx.p !== provider || ctx.t < now() || given.length !== ctx.s.length || !crypto.timingSafeEqual(Buffer.from(given), Buffer.from(ctx.s))) return authFail(res, 'That sign-in link expired. Please try again.');
    const code = params.get('code'); if (!code) return authFail(res, P.label + ' did not send a sign-in code.');
    const tr = await fetch(P.token, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, signal: AbortSignal.timeout(10000),
      body: new URLSearchParams({ grant_type: 'authorization_code', code, redirect_uri: redirectUri, client_id: P.id(), client_secret: P.secret() }) });
    const tj = await tr.json().catch(() => ({}));
    if (!tr.ok || !tj.id_token) { console.error('token exchange failed', provider, tr.status, tj); return authFail(res, P.label + ' sign-in failed. Please try again.'); }
    const claims = await verifyIdToken(P, tj.id_token, ctx.n);
    let appleUser = null; try { appleUser = params.get('user') ? JSON.parse(params.get('user')) : null; } catch (e) { /* ignore */ }
    return finishOAuth(req, res, provider, P, claims, ctx, appleUser);
  } catch (e) { console.error('oauth error', e.message); return authFail(res, e instanceof HttpError ? e.message : 'Sign-in failed. Please try again.'); }
}
function finishOAuth(req, res, provider, P, claims, ctx, appleUser) {
  const email = String(claims.email || (appleUser && appleUser.email) || '').trim().toLowerCase();
  const verified = claims.email_verified === true || claims.email_verified === 'true';
  const existing = one('SELECT i.user_id,u.status FROM identities i JOIN users u ON u.id=i.user_id WHERE i.provider=? AND i.subject=?', provider, String(claims.sub));
  if (ctx.l) { // connecting a provider to the account that is signed in
    const u = sessionUser(req); if (!u || u.id !== ctx.l) return authFail(res, 'Sign in again, then connect ' + P.label + '.');
    if (existing && existing.user_id !== u.id) return authFail(res, 'That ' + P.label + ' account is already connected to someone else.');
    if (!existing) run('INSERT INTO identities(provider,subject,user_id,email,created_at) VALUES(?,?,?,?,?)', provider, String(claims.sub), u.id, email, now());
    return redirect(res, '/#/me');
  }
  if (existing) { createSession(res, existing.user_id); return redirect(res, '/#/'); }
  if (!ctx.a) return authFail(res, 'Please read and accept the Rules, Terms and Privacy Policy first. Choose Join, tick the box, then try again.');
  if (!email || !verified) return authFail(res, P.label + " didn't share a verified email address, so we can't create an account from it.");
  if (one('SELECT 1 x FROM users WHERE email=?', email)) return authFail(res, 'An account with ' + email + ' already exists. Sign in with your password, then connect ' + P.label + ' from your profile.');
  const first = !one('SELECT 1 x FROM users LIMIT 1'), isOwner = first || (CFG.adminEmail && email === CFG.adminEmail && !one("SELECT 1 x FROM users WHERE role='admin'")), mode = signupMode();
  let status = 'active', invite = null;
  if (!isOwner) {
    if (mode === 'closed') return authFail(res, 'Sign-ups are closed right now.');
    if (mode === 'invite') { invite = ctx.i; if (!invite || !one('SELECT 1 x FROM invites WHERE code=? AND used_by IS NULL', invite)) return authFail(res, 'Joining is by invite. Open your invite link first, then choose ' + P.label + '.'); }
    if (mode === 'approval') status = 'pending';
  }
  const nm = clip((appleUser && appleUser.name ? [appleUser.name.firstName, appleUser.name.lastName].filter(Boolean).join(' ') : '') || claims.name || email.split('@')[0], 40) || 'Member';
  const id = tx(() => {
    const r = run('INSERT INTO users(handle,name,email,pass,role,status,created_at,accepted_at,terms_version) VALUES(?,?,?,?,?,?,?,?,?)', uniqueHandle(email.split('@')[0]), nm, email, 'oauth:' + rid(8), isOwner ? 'admin' : 'user', isOwner ? 'active' : status, now(), now(), policiesStamp());
    run('INSERT INTO identities(provider,subject,user_id,email,created_at) VALUES(?,?,?,?,?)', provider, String(claims.sub), r.lastInsertRowid, email, now());
    if (invite) run('UPDATE invites SET used_by=? WHERE code=?', r.lastInsertRowid, invite);
    return Number(r.lastInsertRowid);
  });
  createSession(res, id);
  return redirect(res, '/#/');
}

/* ---------- public policy pages: /rules /terms /privacy /contact (plain HTML, no JavaScript needed) ---------- */
const LEGAL = { '/rules': ['rules', 'Community rules'], '/terms': ['terms', 'Terms of use'], '/privacy': ['privacy', 'Privacy policy'], '/contact': ['contact', 'Contact'] };
function legalPage(req, res, kind, title) {
  const v = policyVars(), e = POL.esc, site = e(v.site);
  const text = kind === 'contact' ? POL.DEFAULTS.contact : policyText(kind);
  const body = POL.renderBody(POL.fill(text, v));
  const updated = new Date(+policiesStamp()).toISOString().slice(0, 10);
  const links = Object.entries(LEGAL).map(([href, [, label]]) => `<a href="${href}">${label.replace('Community rules', 'Rules').replace('Terms of use', 'Terms').replace('Privacy policy', 'Privacy')}</a>`).join(' ');
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${e(title)} - ${site}</title><link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="/style.css"></head>
<body class="legal-page"><header class="top"><a class="brand" href="/"><span class="serif">${site}</span></a><nav class="nav legal-nav" aria-label="Policies">${links}</nav></header>
<main class="legal"><h1 class="serif">${e(title)}</h1>${kind === 'contact' ? '' : `<p class="mono muted">Last updated ${updated}</p>`}${body}<p class="legal-back"><a class="btn" href="/">Back to ${site}</a></p></main>
<footer class="foot"><nav class="foot-links" aria-label="Policies">${links}</nav></footer></body></html>`;
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache', 'Content-Length': Buffer.byteLength(html) });
  res.end(req.method === 'HEAD' ? undefined : html);
}

/* ---------- http plumbing ---------- */
function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=(self), xr-spatial-tracking=(self), fullscreen=(self)');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
}
async function api(req, res, url) {
  try {
    const method = req.method === 'HEAD' ? 'GET' : req.method;
    let hit = null, m;
    for (const r of routes) { if (r.method === method && (m = r.re.exec(url.pathname))) { hit = { r, m }; break; } }
    if (!hit) {
      if (url.pathname === '/api/admin/update/upload' && req.method === 'POST') {
        const u = sessionUser(req); need(u && u.status === 'active' && u.role === 'admin', 403, 'Not allowed');
        return await handleUpdateUpload(req, res, u);
      }
      if (url.pathname === '/api/upload' && req.method === 'POST') { const u = sessionUser(req); need(u, 401, 'Sign in first.'); need(u.status === 'active', 403, 'Your account is not active.'); return handleUpload(req, res, u); }
      throw new HttpError(404, 'Not found');
    }
    const { r } = hit, params = {}; r.keys.forEach((k, i) => { params[k] = decodeURIComponent(hit.m[i + 1]); });
    const user = sessionUser(req);
    if (!r.opts.anon) {
      need(user, 401, 'Sign in first.');
      if (!r.opts.anyStatus) { need(user.status !== 'banned', 403, 'banned'); need(user.status === 'active', 403, 'pending'); }
      if (r.opts.admin) need(user.role === 'admin', 403, 'Not allowed');
    }
    let body = {};
    if (method !== 'GET') {
      const origin = req.headers.origin; if (origin) { try { need(new URL(origin).host === req.headers.host, 403, 'Forbidden'); } catch (e) { if (e instanceof HttpError) throw e; throw new HttpError(403, 'Forbidden'); } }
      need(String(req.headers['content-type'] || '').startsWith('application/json') || req.headers['content-length'] === '0' && req.headers['x-requested-with'] === 'wraparound', 403, 'Forbidden');
      body = await readJson(req);
    }
    const out = await r.fn({ req, res, user, params, query: url.searchParams, body });
    if (r.opts.raw) return;
    json(res, 200, out === undefined ? { ok: true } : out);
  } catch (e) {
    if (e instanceof HttpError) return json(res, e.code, { error: e.message });
    console.error(e); json(res, 500, { error: 'Something went wrong on the server.' });
  }
}
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.txt': 'text/plain; charset=utf-8' };
function serveStatic(req, res, p) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return json(res, 405, { error: 'Method not allowed' });
  let rel = p === '/' ? '/index.html' : p;
  try { rel = decodeURIComponent(rel); } catch (e) { return json(res, 400, { error: 'Bad path' }); }
  let file = path.join(PUBLIC, path.normalize(rel));
  if (!file.startsWith(PUBLIC + path.sep) && file !== PUBLIC) return json(res, 403, { error: 'Forbidden' });
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) { if (path.extname(rel)) return json(res, 404, { error: 'Not found' }); file = path.join(PUBLIC, 'index.html'); }
  const ext = path.extname(file), stat = fs.statSync(file);
  res.writeHead(200, { 'Content-Type': TYPES[ext] || 'application/octet-stream', 'Content-Length': stat.size, 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300' });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}
const server = http.createServer((req, res) => {
  securityHeaders(res);
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/api/')) return api(req, res, url);
  if (url.pathname.startsWith('/auth/')) return authRoute(req, res, url);
  if (LEGAL[url.pathname.replace(/\/$/, '')] && (req.method === 'GET' || req.method === 'HEAD')) return legalPage(req, res, ...LEGAL[url.pathname.replace(/\/$/, '')]);
  if (url.pathname.startsWith('/media/')) return serveMedia(req, res, url.pathname.slice(7));
  serveStatic(req, res, url.pathname);
});
server.requestTimeout = 0; // uploads can be slow on mobile connections
server.headersTimeout = 20000;
function openBrowser(url) {
  const { spawn } = require('node:child_process');
  const [cmd, args] = process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]] : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
  try { const c = spawn(cmd, args, { stdio: 'ignore', detached: true }); c.on('error', () => {}); c.unref(); } catch (e) { /* no browser to open */ }
}
if (require.main === module) {
  const url = `http://localhost:${CFG.port}`;
  server.on('error', (e) => {
    if (e.code === 'EADDRINUSE') {
      console.log(`\nPort ${CFG.port} is already in use. ${CFG.siteName} is probably already running, so opening it for you.\nIf it is not, close the other program or set a different PORT.`);
      if (process.env.OPEN_BROWSER === '1') openBrowser(url);
      process.exit(78);
    } else console.error(e);
    process.exit(1);
  });
  server.listen(CFG.port, () => {
    console.log(`${CFG.siteName} is running on ${url} (data in ${CFG.dataDir})`);
    if (process.env.OPEN_BROWSER === '1') { console.log('Opening it in your browser. Leave this window open while you use the site. Close it to stop the site.'); openBrowser(url); }
  });
  const stop = () => { server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 3000).unref(); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
module.exports = { server, db, CFG };
