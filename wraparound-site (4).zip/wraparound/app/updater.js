'use strict';
/*
 * Installs updates from the admin panel.
 *
 * An update package is a zip that contains an "app" folder (the same one this site runs from). Installing one:
 *   1. unpacks it to a staging folder, refusing unsafe paths and unexpected file types,
 *   2. checks every .js file for syntax errors,
 *   3. starts the new version on a spare port with an empty temporary database, and makes sure it answers,
 *   4. (when you confirm) backs up the database, switches to the new version and restarts.
 * The previous version is kept, so you can roll back with one click. If a new version crashes as it starts,
 * the launcher (server.js) switches back by itself.
 *
 * Versions live in DATA_DIR/versions, so they survive restarts, Docker rebuilds and moves to a new server.
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn, spawnSync } = require('node:child_process');
const { readZip } = require('./zip.js');

const ALLOWED_EXT = new Set(['.js', '.json', '.css', '.html', '.svg', '.png', '.jpg', '.jpeg', '.ico', '.txt', '.md', '.webmanifest', '.woff2']);
const REQUIRED = ['main.js', 'policies.js', 'zip.js', 'updater.js', 'version.json', 'public/index.html'];
const VERSION_RE = /^\d+\.\d+\.\d+[\w.-]{0,20}$/;
const MAX_UPLOAD = 60 * 1024 * 1024;

function createUpdater({ dataDir, appDir, backupDb }) {
  const stateFile = path.join(dataDir, 'versions.json'), versionsDir = path.join(dataDir, 'versions'), stagingDir = path.join(dataDir, 'staging');
  const bundledDir = process.env.BUNDLED_APP_DIR || appDir;
  const supervised = process.env.SUPERVISED === '1';

  const readState = () => { try { const s = JSON.parse(fs.readFileSync(stateFile, 'utf8')); return { current: 'bundled', previous: null, failed: null, history: [], ...s }; } catch (e) { return { current: 'bundled', previous: null, failed: null, history: [] }; } };
  const writeState = (s) => { fs.mkdirSync(dataDir, { recursive: true }); fs.writeFileSync(stateFile + '.tmp', JSON.stringify(s, null, 2)); fs.renameSync(stateFile + '.tmp', stateFile); };
  const dirFor = (id) => (id === 'bundled' ? bundledDir : path.join(versionsDir, id, 'app'));
  function versionOf(dir) {
    try { const v = JSON.parse(fs.readFileSync(path.join(dir, 'version.json'), 'utf8')); return { version: String(v.version || '?'), notes: String(v.notes || '') }; } catch (e) { return { version: '?', notes: '' }; }
  }
  const describe = (id) => (id && fs.existsSync(path.join(dirFor(id), 'main.js')) ? { id, ...versionOf(dirFor(id)) } : null);

  function info() {
    const st = readState();
    return {
      supervised,
      running: { id: process.env.APP_VERSION_ID || 'bundled', ...versionOf(appDir) },
      bundled: versionOf(bundledDir),
      previous: describe(st.previous),
      failed: st.failed ? { id: st.failed, ...(describe(st.failed) || {}) } : null,
      history: st.history.slice(-8).reverse()
    };
  }

  function walk(dir, base = dir, out = new Map()) {
    if (!fs.existsSync(dir)) return out;
    for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, f.name);
      if (f.isDirectory()) { if (f.name !== 'node_modules') walk(full, base, out); }
      else out.set(path.relative(base, full).split(path.sep).join('/'), crypto.createHash('sha256').update(fs.readFileSync(full)).digest('hex'));
    }
    return out;
  }

  function syntaxCheck(dir) {
    const bad = [];
    for (const rel of walk(dir).keys()) {
      if (!rel.endsWith('.js')) continue;
      const r = spawnSync(process.execPath, ['--check', path.join(dir, rel)], { encoding: 'utf8' });
      if (r.status !== 0) bad.push(rel + ': ' + (String(r.stderr).split('\n').find((l) => /Error/.test(l)) || 'syntax error'));
    }
    return bad;
  }

  function bootTest(mainPath) {
    return new Promise((resolve) => {
      const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'wrap-boot-')), port = 41000 + Math.floor(Math.random() * 20000);
      const child = spawn(process.execPath, ['--no-warnings', mainPath], { env: { PATH: process.env.PATH, PORT: String(port), DATA_DIR: tmp, SIGNUP_MODE: 'closed', OPEN_BROWSER: '0' }, stdio: ['ignore', 'pipe', 'pipe'] });
      let out = '', done = false, probed = false;
      const finish = (ok, msg) => { if (done) return; done = true; clearTimeout(timer); child.kill('SIGKILL'); setTimeout(() => fs.rmSync(tmp, { recursive: true, force: true }), 400); resolve({ ok, msg }); };
      const tail = () => out.trim().split('\n').slice(-3).join(' ').slice(0, 300);
      child.stdout.on('data', async (d) => {
        out += d;
        if (probed || !/is running on/.test(out)) return;
        probed = true;
        try {
          const rs = await Promise.all(['/api/config', '/', '/rules'].map((p) => fetch(`http://127.0.0.1:${port}${p}`)));
          finish(rs.every((r) => r.ok), rs.every((r) => r.ok) ? 'Starts up and answers requests.' : 'It started but did not answer requests correctly.');
        } catch (e) { finish(false, 'It started but could not be reached.'); }
      });
      child.stderr.on('data', (d) => { out += d; });
      child.on('exit', () => finish(false, 'It crashed on startup. ' + tail()));
      const timer = setTimeout(() => finish(false, 'It did not start within 20 seconds.'), 20000);
    });
  }

  function cleanStaging() {
    if (!fs.existsSync(stagingDir)) return;
    for (const f of fs.readdirSync(stagingDir)) { try { const p = path.join(stagingDir, f); if (Date.now() - fs.statSync(p).mtimeMs > 3600e3) fs.rmSync(p, { recursive: true, force: true }); } catch (e) { /* ignore */ } }
  }

  /* Unpack, verify and test a zip. Returns a summary. Throws Error(message) with a plain-English reason if it is not usable. */
  async function check(zipBuf) {
    cleanStaging();
    const zip = readZip(zipBuf);
    const main = zip.entries.filter((e) => /(^|\/)app\/main\.js$/.test(e.name)).sort((a, b) => a.name.length - b.name.length)[0];
    if (!main) throw new Error('This does not look like a Wraparound update. It has no "app" folder with main.js in it. Use the update zip you were given.');
    const prefix = main.name.slice(0, main.name.length - 'main.js'.length); // "...app/"
    const files = zip.entries.filter((e) => e.name.startsWith(prefix)).map((e) => ({ e, rel: e.name.slice(prefix.length) })).filter((f) => f.rel);
    for (const f of files) {
      if (!ALLOWED_EXT.has(path.extname(f.rel).toLowerCase())) throw new Error('The update contains a file type that is not allowed (' + f.rel + ').');
    }
    for (const need of REQUIRED) if (!files.some((f) => f.rel === need)) throw new Error('The update is missing a required file (' + need + ').');

    const vFile = JSON.parse(zip.read(files.find((f) => f.rel === 'version.json').e).toString('utf8') || '{}');
    if (!VERSION_RE.test(String(vFile.version || ''))) throw new Error('The update has no valid version number in version.json.');

    const id = Date.now().toString(36) + '-' + vFile.version.replace(/[^a-z0-9.]/gi, '').toLowerCase().slice(0, 24);
    const dest = path.join(stagingDir, id, 'app');
    try {
      for (const f of files) {
        const out = path.join(dest, f.rel);
        if (!out.startsWith(dest + path.sep)) throw new Error('The zip contains an unsafe file path.');
        fs.mkdirSync(path.dirname(out), { recursive: true });
        fs.writeFileSync(out, zip.read(f.e));
      }
      const bad = syntaxCheck(dest);
      if (bad.length) throw new Error('The update has a programming error and was not installed: ' + bad.join('; '));
      const boot = await bootTest(path.join(dest, 'main.js'));
      if (!boot.ok) throw new Error('The update failed its start-up test and was not installed. ' + boot.msg);

      const now = walk(appDir), next = walk(dest), added = [], changed = [], removed = [];
      next.forEach((h, k) => { if (!now.has(k)) added.push(k); else if (now.get(k) !== h) changed.push(k); });
      now.forEach((h, k) => { if (!next.has(k)) removed.push(k); });
      return { id, version: String(vFile.version), notes: String(vFile.notes || '').slice(0, 1000), files: { added, changed, removed }, checks: ['All files are an allowed type', 'No programming errors found', boot.msg] };
    } catch (e) { fs.rmSync(path.join(stagingDir, id), { recursive: true, force: true }); throw e; }
  }

  function prune(st) {
    if (!fs.existsSync(versionsDir)) return;
    const keep = new Set([st.current, st.previous]);
    const others = fs.readdirSync(versionsDir).filter((d) => !keep.has(d)).map((d) => ({ d, t: fs.statSync(path.join(versionsDir, d)).mtimeMs })).sort((a, b) => b.t - a.t);
    others.slice(2).forEach((o) => fs.rmSync(path.join(versionsDir, o.d), { recursive: true, force: true }));
  }

  function apply(id) {
    if (!/^[a-z0-9][a-z0-9.-]{3,60}$/.test(String(id))) throw new Error('Unknown update.');
    const staged = path.join(stagingDir, id);
    if (!fs.existsSync(path.join(staged, 'app', 'main.js'))) throw new Error('That update is no longer waiting. Upload it again.');
    backupDb('before-update');
    fs.mkdirSync(versionsDir, { recursive: true });
    fs.renameSync(staged, path.join(versionsDir, id));
    const st = readState(), from = st.current;
    st.previous = from; st.current = id; st.failed = null;
    const version = versionOf(dirFor(id)).version;
    st.history.push({ at: Date.now(), event: 'update', from, to: id, version });
    writeState(st); prune(st);
    return { version };
  }

  function rollback() {
    const st = readState();
    const target = st.previous || (st.current !== 'bundled' ? 'bundled' : null);
    if (!target || !fs.existsSync(path.join(dirFor(target), 'main.js'))) throw new Error('There is no earlier version to go back to.');
    const from = st.current; st.previous = from; st.current = target; st.failed = null;
    st.history.push({ at: Date.now(), event: 'rollback', from, to: target, version: versionOf(dirFor(target)).version });
    writeState(st);
    return { version: versionOf(dirFor(target)).version };
  }

  return { info, check, apply, rollback, MAX_UPLOAD, supervised };
}

module.exports = { createUpdater };
