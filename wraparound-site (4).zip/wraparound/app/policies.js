'use strict';
/*
 * Starting-point text for the Rules, Terms, Privacy Policy and Contact pages, plus a tiny safe renderer.
 * These are plain-language templates, not legal advice. The owner can edit every word in Admin, then Policies.
 *
 * Fill-ins that the site replaces automatically: {{site}} {{operator}} {{contact}} {{domain}} {{min_age}}
 * A part written like [[this]] is something the owner still has to fill in; the admin launch checklist flags it.
 *
 * Formatting: "## Heading", "- bullet", a blank line between paragraphs, **bold**. Email addresses become links.
 */

const RULES = `## The short version
{{site}} is a place for people who play VR to share clips and hang out. Be decent to each other, only post what you have the right to post, and keep it legal. The people who run the site can remove content and accounts that break these rules.

## What is not allowed
- Harassment, bullying or threats, including in voice chat clips and group chats.
- Hate: attacking people for their race, ethnicity, nationality, religion, caste, sex, gender, sexual orientation, disability, age or serious illness.
- Anything sexual involving minors. There is zero tolerance for this. The content is removed, the account is banned for good, and it is reported to the authorities.
- Pornography, nudity, and sexually explicit clips or messages.
- Graphic violence or gore, and anything that encourages self-harm, suicide or eating disorders.
- Illegal content, or anything that helps someone commit a crime, including fraud, scams and stolen accounts.
- Sharing someone's private information without their permission (doxxing), such as their address, phone number or real name when they have not shared it themselves.
- Pretending to be another person, or pretending to be staff.
- Spam, ads nobody asked for, and fake accounts.
- Cheats, hacks or exploits that harm other players, and anything that spreads malware.

## Your clips
- Only post what you made or have permission to share. Gameplay footage is usually fine, but please do not upload films, TV or music you do not own the rights to. Music inside a game can still be protected by copyright.
- Be honest about what a video is. Tick the 360° box only for real 360° videos so people know they can look around.
- If a clip has fast flashing lights, strobing or intense motion, say so in the caption. Some people get motion sick or have seizures.
- VR records other people. If someone's avatar, voice or real-world surroundings are in your clip, think about whether they would be fine with it. Take it down if they ask.

## Groups and messages
- A group chat can be read by every member of that group, and by the site owner. Do not share anything you would not want others to see.
- Do not message or invite people who have asked you to stop.

## If something is wrong
Use the Report button under a post, or email {{contact}}. Every report is read. Depending on how serious it is, we may remove the content, give a warning, turn off your account, or remove you for good. If you think we got it wrong, email us and we will take another look.
`;

const TERMS = `## About these terms
These terms are an agreement between you and {{operator}} ("we", "us"), who run {{site}} at {{domain}}. By creating an account or using {{site}} you agree to these terms, the Community Rules and the Privacy Policy. If you do not agree, please do not use the site.

## Who can use it
You must be at least {{min_age}} years old. If you are under the age of adulthood where you live, you need a parent or guardian's permission. Give accurate information when you sign up. You are responsible for what happens on your account, so keep your password safe.

## Your content
You keep ownership of the videos, photos, messages and other content you post. To run the site, you give us a non-exclusive, worldwide, royalty-free licence to store, copy, display and play your content to the people you share it with on {{site}}, and to make technical copies such as backups. This licence ends when you delete the content or your account, except that backup copies are removed within a reasonable time.
You promise that you have the right to post your content, and that it follows the Community Rules and the law.

## What we can do
We can remove content, limit features, or suspend or delete accounts that break these terms or the Community Rules, or that put others at risk, with or without notice. We may keep a record of reports and the action taken. We can change or stop the site at any time.

## Copyright complaints
If you believe something on {{site}} infringes your copyright, email {{contact}} with: what you own, a link to where it appears on the site, your name and contact details, a statement that you believe in good faith that the use is not allowed, and a statement that your information is accurate and that you are the owner or are authorised to act for them. We will review it, and may remove the content and tell the person who posted it. People who repeatedly infringe can lose their accounts.

## Calls
Audio and video calls go directly between the people on the call. We do not record calls. Anyone on a call can record it on their own device, so only call people you trust.

## No guarantees
{{site}} is provided "as is" and "as available". We do not promise it will always work or be free of errors, or that your content will never be lost, so keep your own copies of anything important. We do not check or endorse what members post.

## Limits on our responsibility
To the fullest extent the law allows, we are not responsible for what other members post or do, for loss of content, or for indirect or consequential losses. Nothing in these terms limits anything that the law does not allow us to limit, such as responsibility for death or personal injury caused by negligence, or for fraud.

## Ending your account
You can delete your account at any time from Your profile. We can end it as described above.

## Changes and governing law
We may change these terms. If a change matters, we will tell members on the site before it takes effect, and if you keep using {{site}} after that you accept the new terms. These terms are governed by the laws of [[your state or country]], and the courts there can decide disputes, unless the law where you live gives you rights that cannot be limited by contract.

## Contact
{{contact}}
`;

const PRIVACY = `## Who we are
{{site}} at {{domain}} is run by {{operator}}. For anything about your data, email {{contact}}.

## What we collect
- **Your account:** your name, username, email address and password. Passwords are stored scrambled (hashed) and we cannot read them. If you sign in with Google or Apple, we receive your name and email from them, plus a unique ID for your account with them.
- **What you post and send:** videos, photos, captions, comments, direct messages and group messages, your profile photo and bio, who you follow, your friends and the groups you join.
- **Technical data:** a sign-in cookie that keeps you logged in. We use your IP address briefly to limit abuse, for example many failed sign-ins. The web server may keep ordinary access logs.

We do not use advertising, tracking or analytics cookies, and we do not sell your data. The only cookie we set is the one that keeps you signed in, which the site cannot work without.

## Why we use it
To run the site: to create your account, show your posts to others, deliver messages, make calls work, keep the site safe and answer reports. Where the law asks for a legal basis, it is our need to provide the service you asked for, and our legitimate interest in keeping the site safe.

## Who can see it
- Other members can see your name, username, bio, profile photo, posts, comments and the groups you join. A direct message is visible to the two people in it. A group message is visible to everyone in that group.
- The site owner, and anyone they authorise to look after the server, can access everything stored on it, including messages. We only look at private content when needed to handle a report, keep the site safe, or meet a legal duty.
- **Calls** go directly between browsers. To connect, your browser contacts STUN servers (public ones run by Google, unless we set up our own), which see your IP address. If a relay (TURN) server is needed, your call passes through it, still encrypted.
- **Google and Apple** learn that you signed in to {{site}} if you use those buttons. See their own privacy policies.
- We may share information if the law requires it, or to protect someone's safety.

## How long we keep it
Until you delete it or delete your account. When you delete your account, your profile, posts, messages and uploaded files are removed from the site. Backups may hold copies for a short time afterwards. We may keep a small record of reports and bans where needed to protect the site.

## Your choices and rights
- Download a copy of your data, and delete your account, from **Your profile**.
- Edit your profile, delete posts and leave groups at any time.
- Depending on where you live (for example the EU, the UK or California) you may also have the right to ask us to access, correct, delete or move your data, to object to how we use it, and to complain to your data protection authority. Email {{contact}} and we will reply within a month.

## Children
{{site}} is for people aged {{min_age}} and over. We do not knowingly collect data from younger children. If you think a child has signed up, email {{contact}} and we will delete the account.

## Where data is kept
On the server where {{site}} is hosted, which may be in a different country from you.

## Security
Passwords are hashed, connections use HTTPS, and access to the server is limited. No system is perfectly secure, so please use a strong, unique password.

## Changes
We will update this page when things change, and show the date at the top. If a change matters, we will tell members on the site.
`;

const CONTACT = `## Get in touch
{{contact}}

## Reporting something
- To report a post, use the **Report** button under it. Reports are read by the site owner.
- To report a person, a group, or a message, email us and tell us where to find it.
- If you think something shows a child being harmed, email us straight away. It is removed and reported to the authorities.

## Other requests
- Copyright complaints and takedown requests: email us. See the Terms for what to include.
- Questions about your data, or a request to see, correct or delete it: email us, or use **Your profile** on the site to download your data or delete your account.
`;

const DEFAULTS = { rules: RULES, terms: TERMS, privacy: PRIVACY, contact: CONTACT };

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function fill(text, vars) {
  return String(text).replace(/\{\{(\w+)\}\}/g, (m, k) => (vars[k] != null && vars[k] !== '' ? String(vars[k]) : m));
}
function inline(s) {
  let e = esc(s);
  e = e.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  e = e.replace(/\[\[(.+?)\]\]/g, '<mark>[$1]</mark>');
  e = e.replace(/([A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+)/g, '<a href="mailto:$1">$1</a>');
  return e;
}
function renderBody(text) {
  const html = []; let para = [], list = [];
  const flushPara = () => { if (para.length) { html.push('<p>' + inline(para.join(' ')) + '</p>'); para = []; } };
  const flushList = () => { if (list.length) { html.push('<ul>' + list.map((li) => '<li>' + inline(li) + '</li>').join('') + '</ul>'); list = []; } };
  for (const raw of String(text).replace(/\r/g, '').split('\n')) {
    const line = raw.trimEnd(); let m;
    if (!line.trim()) { flushPara(); flushList(); }
    else if ((m = /^##\s+(.*)$/.exec(line))) { flushPara(); flushList(); html.push('<h2>' + inline(m[1]) + '</h2>'); }
    else if ((m = /^[-*]\s+(.*)$/.exec(line))) { flushPara(); list.push(m[1]); }
    else { flushList(); para.push(line.trim()); }
  }
  flushPara(); flushList();
  return html.join('\n');
}
const hasPlaceholders = (text) => /\[\[.+?\]\]|\{\{\w+\}\}/.test(text);

module.exports = { DEFAULTS, fill, renderBody, hasPlaceholders, esc };
