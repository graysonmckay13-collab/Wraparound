// Tests the admin "Update" feature end to end: real launcher, real zip files, real restarts.
import { spawn } from 'node:child_process';
import { mkdtempSync, readFileSync, readdirSync, statSync, existsSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import zlib from 'node:zlib';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const appDir = path.join(root, 'app');
const dataDir = mkdtempSync(path.join(tmpdir(), 'wrap-upd-'));
const PORT = 5200 + Math.floor(Math.random() * 400), BASE = `http://127.0.0.1:${PORT}`;
const proc = spawn(process.execPath, ['--no-warnings', 'server.js'], { cwd: root, env: { ...process.env, PORT, DATA_DIR: dataDir, SIGNUP_MODE: 'invite', OPEN_BROWSER: '0' }, stdio: ['ignore', 'pipe', 'inherit'] });
let log = ''; proc.stdout.on('data', (d) => { log += d; });
const until = async (fn, ms = 20000, label = 'condition') => { const t = Date.now(); for (;;) { try { const v = await fn(); if (v) return v; } catch { /* keep trying */ } if (Date.now() - t > ms) throw new Error('timed out waiting for ' + label + '\n' + log.slice(-600)); await new Promise((r) => setTimeout(r, 150)); } };
await until(() => /is running on/.test(log), 10000, 'server start');

let passed = 0; const ok = (n) => { passed++; console.log('  ok  ' + n); };
function client() {
  let cookie = '';
  const c = {
    async req(method, url, body, extra = {}) {
      const headers = { cookie, ...extra }; let payload;
      if (body instanceof Uint8Array) payload = body;
      else if (body !== undefined || method !== 'GET') { headers['content-type'] ??= 'application/json'; payload = JSON.stringify(body ?? {}); }
      const r = await fetch(BASE + url, { method, headers, body: method === 'GET' ? undefined : payload });
      const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
      const ct = r.headers.get('content-type') || '';
      return { status: r.status, data: ct.includes('json') ? await r.json() : null, raw: r, headers: r.headers };
    },
    get: (u) => c.req('GET', u), post: (u, b) => c.req('POST', u, b ?? {}),
    upload: (buf, extra = {}) => c.req('POST', '/api/admin/update/upload', buf, { 'content-type': 'application/octet-stream', 'x-requested-with': 'wraparound', ...extra })
  };
  return c;
}

/* ---- tiny zip writer ---- */
function makeZip(entries) {
  const parts = [], cds = []; let off = 0;
  for (const { name, data } of entries) {
    const nameB = Buffer.from(name), comp = zlib.deflateRawSync(data), crc = zlib.crc32(data) >>> 0;
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x800, 6); lh.writeUInt16LE(8, 8); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(nameB.length, 26);
    parts.push(lh, nameB, comp);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x800, 8); ch.writeUInt16LE(8, 10); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(comp.length, 20); ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(nameB.length, 28); ch.writeUInt32LE(off, 42);
    cds.push(ch, nameB); off += 30 + nameB.length + comp.length;
  }
  const cd = Buffer.concat(cds), eocd = Buffer.alloc(22); eocd.writeUInt32LE(0x06054b50, 0); eocd.writeUInt16LE(entries.length, 8); eocd.writeUInt16LE(entries.length, 10); eocd.writeUInt32LE(cd.length, 12); eocd.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cd, eocd]);
}
function appEntries(dir = appDir, base = '') { const out = []; for (const f of readdirSync(dir)) { const p = path.join(dir, f); if (statSync(p).isDirectory()) out.push(...appEntries(p, base + f + '/')); else out.push({ name: base + f, data: readFileSync(p) }); } return out; }
function pkg({ version, notes = 'test', edit = (e) => e, prefix = 'wraparound/app/', extra = [] }) {
  let es = appEntries().map((e) => ({ ...e }));
  es = es.map((e) => (e.name === 'version.json' ? { name: e.name, data: Buffer.from(JSON.stringify({ version, notes })) } : e));
  es = edit(es);
  return makeZip([...es.map((e) => ({ name: prefix + e.name, data: e.data })), { name: 'wraparound/README.md', data: Buffer.from('ignored') }, ...extra]);
}
const withEdit = (name, fn) => (es) => es.map((e) => (e.name === name ? { name, data: Buffer.from(fn(e.data.toString())) } : e));

try {
  const owner = client(), member = client(), anon = client();
  const bundledVersion = JSON.parse(readFileSync(path.join(appDir, 'version.json'), 'utf8')).version;
  let r = await owner.post('/api/register', { agree: true, handle: 'boss', name: 'Boss', email: 'boss@example.com', password: 'longenough1' }); assert.equal(r.status, 200);
  const inv = (await owner.post('/api/admin/invites', { count: 1 })).data.codes[0];
  r = await member.post('/api/register', { agree: true, handle: 'mem', name: 'Mem', email: 'mem@example.com', password: 'longenough1', invite: inv }); assert.equal(r.status, 200);
  const cfg = async () => (await anon.get('/api/config')).data;
  const boot0 = await cfg(); assert.equal(boot0.appVersion, bundledVersion);

  console.log('Access');
  r = await owner.get('/api/admin/update'); assert.equal(r.data.supervised, true); assert.equal(r.data.running.version, bundledVersion); assert.equal(r.data.previous, null); ok('update info shows the running version and that the launcher is in charge');
  for (const [who, c] of [['member', member], ['anonymous', anon]]) {
    r = await c.get('/api/admin/update'); assert.ok([401, 403].includes(r.status));
    r = await c.upload(pkg({ version: '9.0.0' })); assert.ok([401, 403].includes(r.status), who + ' upload');
    r = await c.post('/api/admin/update/apply', { id: 'x', confirm: 'longenough1' }); assert.ok([401, 403].includes(r.status));
    r = await c.post('/api/admin/restart', { confirm: 'longenough1' }); assert.ok([401, 403].includes(r.status));
  }
  r = await owner.upload(pkg({ version: '9.0.0' }), { 'x-requested-with': 'nope' }); assert.equal(r.status, 403); ok('only the owner can reach the update tools, and uploads need the safety header');

  console.log('Bad packages are refused');
  r = await owner.upload(Buffer.from('definitely not a zip file, just some text that is long enough')); assert.equal(r.status, 400); assert.match(r.data.error, /zip/i);
  r = await owner.upload(makeZip([{ name: 'hello.txt', data: Buffer.from('hi') }])); assert.equal(r.status, 400); assert.match(r.data.error, /does not look like/i);
  r = await owner.upload(pkg({ version: '9.0.1', extra: [{ name: 'wraparound/../../evil.js', data: Buffer.from('x') }] })); assert.equal(r.status, 400); assert.match(r.data.error, /unsafe/i);
  r = await owner.upload(pkg({ version: '9.0.1', extra: [{ name: 'wraparound/app/tool.exe', data: Buffer.from('MZ') }] })); assert.equal(r.status, 400); assert.match(r.data.error, /not allowed/i);
  r = await owner.upload(pkg({ version: '9.0.1', edit: (es) => es.filter((e) => e.name !== 'policies.js') })); assert.equal(r.status, 400); assert.match(r.data.error, /missing a required file/i);
  r = await owner.upload(pkg({ version: 'banana' })); assert.equal(r.status, 400); assert.match(r.data.error, /version/i);
  r = await owner.upload(pkg({ version: '9.0.1', edit: withEdit('main.js', (t) => t + '\nthis is ( not valid javascript') })); assert.equal(r.status, 400); assert.match(r.data.error, /programming error/i);
  r = await owner.upload(pkg({ version: '9.0.1', edit: withEdit('main.js', (t) => t.replace("'use strict';", "'use strict';\nthrow new Error('boom at startup');")) })); assert.equal(r.status, 400); assert.match(r.data.error, /start-up test/i); ok('bad zips, unsafe paths, wrong file types, missing files, syntax errors and crashing code are all refused');
  assert.equal(existsSync(path.join(dataDir, 'staging')) ? readdirSync(path.join(dataDir, 'staging')).length : 0, 0); ok('refused packages leave nothing behind');

  console.log('Install, roll back, restart');
  const good = pkg({ version: '9.9.9', notes: 'Marker release', edit: withEdit('public/index.html', (t) => t.replace('</body>', '<!-- marker-999 --></body>')) });
  r = await owner.upload(good); assert.equal(r.status, 200); const staged = r.data;
  assert.equal(staged.version, '9.9.9'); assert.equal(staged.notes, 'Marker release'); assert.ok(staged.files.changed.includes('public/index.html')); assert.ok(staged.files.changed.includes('version.json')); assert.equal(staged.files.added.length, 0); assert.ok(staged.checks.length >= 3); ok('a good package is checked, test-started and summarised');
  r = await owner.post('/api/admin/update/apply', { id: staged.id, confirm: 'wrong-password' }); assert.equal(r.status, 403);
  r = await owner.post('/api/admin/update/apply', { id: '../../etc', confirm: 'longenough1' }); assert.equal(r.status, 400); ok('installing needs the owner password');
  r = await owner.post('/api/admin/update/apply', { id: staged.id, confirm: 'longenough1' }); assert.equal(r.status, 200);
  await until(async () => { const c = await cfg(); return c.startedAt !== boot0.startedAt && c.appVersion === '9.9.9'; }, 25000, 'restart into 9.9.9');
  r = await anon.req('GET', '/'); assert.ok((await r.raw.text()).includes('marker-999'));
  r = await owner.get('/api/me'); assert.equal(r.status, 200); assert.equal(r.data.user.handle, 'boss'); ok('the new version is live, and accounts and sessions carried over');
  assert.ok(readdirSync(path.join(dataDir, 'backups')).some((f) => f.includes('before-update')));
  const bk = readFileSync(path.join(dataDir, 'backups', readdirSync(path.join(dataDir, 'backups')).find((f) => f.includes('before-update')))); assert.equal(bk.subarray(0, 15).toString(), 'SQLite format 3'); ok('a database backup was taken before installing');
  r = await owner.get('/api/admin/update'); assert.equal(r.data.running.version, '9.9.9'); assert.equal(r.data.previous.version, bundledVersion); assert.equal(r.data.history[0].event, 'update');

  const boot1 = (await cfg()).startedAt;
  r = await owner.post('/api/admin/update/rollback', { confirm: 'nope' }); assert.equal(r.status, 403);
  r = await owner.post('/api/admin/update/rollback', { confirm: 'longenough1' }); assert.equal(r.status, 200);
  await until(async () => { const c = await cfg(); return c.startedAt !== boot1 && c.appVersion === bundledVersion; }, 25000, 'rollback');
  r = await anon.req('GET', '/'); assert.ok(!(await r.raw.text()).includes('marker-999')); ok('one-click rollback returns to the previous version');
  const boot2 = (await cfg()).startedAt;
  r = await owner.post('/api/admin/restart', { confirm: 'longenough1' }); assert.equal(r.status, 200);
  await until(async () => (await cfg()).startedAt !== boot2, 20000, 'restart'); ok('restart works');

  console.log('A broken new version rolls itself back');
  const poison = pkg({ version: '9.9.8', edit: withEdit('main.js', (t) => t.replace("'use strict';", "'use strict';\nif (require('fs').existsSync(require('path').join(process.env.DATA_DIR, 'poison'))) { console.error('poisoned on purpose'); process.exit(1); }")) });
  r = await owner.upload(poison); assert.equal(r.status, 200, 'passes the sandbox test because it only fails against the real data folder');
  writeFileSync(path.join(dataDir, 'poison'), 'x'); const boot3 = (await cfg()).startedAt;
  r = await owner.post('/api/admin/update/apply', { id: r.data.id, confirm: 'longenough1' }); assert.equal(r.status, 200);
  await until(async () => { const c = await cfg(); return c.startedAt !== boot3 && c.appVersion === bundledVersion; }, 30000, 'automatic rollback');
  rmSync(path.join(dataDir, 'poison'));
  r = await owner.get('/api/admin/update'); assert.ok(r.data.failed, 'the failed version is reported'); assert.ok(r.data.history.some((h) => h.event === 'auto-rollback')); assert.equal(r.data.running.version, bundledVersion);
  r = await owner.get('/api/me'); assert.equal(r.status, 200); ok('a version that crashes on start is rolled back automatically, and the site stays up');

  console.log('Backup');
  r = await owner.get('/api/admin/backup'); assert.equal(r.status, 200); assert.ok(r.headers.get('content-disposition').includes('attachment')); const body = Buffer.from(await r.raw.arrayBuffer()); assert.equal(body.subarray(0, 15).toString(), 'SQLite format 3');
  r = await member.get('/api/admin/backup'); assert.equal(r.status, 403); ok('the owner can download a database backup; nobody else can');
  console.log(`\n${passed} checks passed`);
} catch (e) { console.error('\nFAILED:', e); process.exitCode = 1; }
finally { proc.kill(); setTimeout(() => process.exit(process.exitCode || 0), 500); }
