// End-to-end smoke test. Starts the real server on a temp data dir and exercises the HTTP API.
import { spawn } from 'node:child_process';
import { mkdtempSync, existsSync, readdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const dataDir = mkdtempSync(path.join(tmpdir(), 'wrap-'));
const PORT = 4100 + Math.floor(Math.random() * 500), BASE = `http://127.0.0.1:${PORT}`;
const proc = spawn(process.execPath, ['--no-warnings', 'server.js'], { cwd: root, env: { ...process.env, PORT, DATA_DIR: dataDir, MAX_UPLOAD_MB: '1', SIGNUP_MODE: 'invite' }, stdio: ['ignore', 'pipe', 'inherit'] });
await new Promise((res, rej) => { proc.stdout.on('data', d => String(d).includes('running') && res()); proc.on('exit', c => rej(new Error('server exited ' + c))); setTimeout(() => rej(new Error('server start timeout')), 8000); });

let passed = 0;
const ok = (name) => { passed++; console.log('  ok  ' + name); };
function client() {
  let cookie = '';
  const c = {
    async req(method, url, body, extra = {}) {
      const headers = { cookie, ...extra };
      let payload;
      if (body !== undefined && !(body instanceof Uint8Array)) { headers['content-type'] ??= 'application/json'; payload = JSON.stringify(body); }
      else if (body instanceof Uint8Array) payload = body;
      else if (method !== 'GET') { headers['content-type'] ??= 'application/json'; payload = '{}'; }
      const r = await fetch(BASE + url, { method, headers, body: payload });
      const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
      if (cookie === 'sid=') cookie = '';
      const ct = r.headers.get('content-type') || '';
      const data = ct.includes('json') ? await r.json() : null;
      return { status: r.status, data, headers: r.headers, raw: r };
    },
    get: (u) => c.req('GET', u), post: (u, b) => c.req('POST', u, b ?? {}), del: (u) => c.req('DELETE', u, {}),
    async sse() {
      const r = await fetch(BASE + '/api/events', { headers: { cookie } });
      assert.equal(r.status, 200);
      const reader = r.body.getReader(), dec = new TextDecoder(); let buf = ''; const events = [];
      (async () => { try { for (;;) { const { value, done } = await reader.read(); if (done) break; buf += dec.decode(value); let i; while ((i = buf.indexOf('\n\n')) >= 0) { const blk = buf.slice(0, i); buf = buf.slice(i + 2); const m = /^data: (.*)$/m.exec(blk); if (m) events.push(JSON.parse(m[1])); } } } catch {} })();
      return { events, async wait(type, ms = 3000) { const t = Date.now(); for (;;) { const e = events.find(x => x.type === type); if (e) { events.splice(events.indexOf(e), 1); return e; } if (Date.now() - t > ms) throw new Error('timeout waiting for ' + type); await new Promise(r => setTimeout(r, 25)); } }, close: () => reader.cancel() };
    }
  };
  return c;
}
const mp4 = (n) => { const b = new Uint8Array(n); b.set([0, 0, 0, 24, 0x66, 0x74, 0x79, 0x70, 0x6d, 0x70, 0x34, 0x32]); for (let i = 12; i < n; i++) b[i] = i % 251; return b; };
const up = (c, bytes) => c.req('POST', '/api/upload', bytes, { 'content-type': 'application/octet-stream', 'x-requested-with': 'wraparound' });
const sleep = ms => new Promise(r => setTimeout(r, ms));

try {
  const owner = client(), amy = client(), bo = client(), anon = client();
  console.log('Accounts and access');
  let r = await anon.get('/api/config'); assert.equal(r.data.firstRun, true); ok('config reports first run');
  r = await owner.post('/api/register', { agree: true, handle: 'owner', name: 'Owner', email: 'owner@example.com', password: 'longenough1' }); assert.equal(r.status, 200);
  r = await owner.get('/api/me'); assert.equal(r.data.user.role, 'admin'); assert.equal(r.data.user.status, 'active'); ok('first account becomes the admin');
  r = await amy.post('/api/register', { agree: true, handle: 'amy', name: 'Amy', email: 'amy@example.com', password: 'longenough1' }); assert.equal(r.status, 403); ok('invite mode blocks sign-up without a code');
  r = await owner.post('/api/admin/invites', { count: 3, note: 'friends' }); const [c1, c2] = r.data.codes; assert.equal(r.data.codes.length, 3);
  r = await amy.post('/api/register', { agree: true, handle: 'amy', name: 'Amy', email: 'amy@example.com', password: 'short', invite: c1 }); assert.equal(r.status, 400); ok('weak password rejected');
  r = await amy.post('/api/register', { agree: true, handle: 'amy', name: 'Amy', email: 'amy@example.com', password: 'longenough1', invite: c1 }); assert.equal(r.status, 200);
  r = await bo.post('/api/register', { agree: true, handle: 'bobo', name: 'Bo', email: 'bo@example.com', password: 'longenough1', invite: c1 }); assert.equal(r.status, 403); ok('an invite code works once');
  r = await bo.post('/api/register', { agree: true, handle: 'bobo', name: 'Bo', email: 'bo@example.com', password: 'longenough1', invite: c2 }); assert.equal(r.status, 200);
  r = await anon.post('/api/login', { email: 'amy@example.com', password: 'nope-nope' }); assert.equal(r.status, 401); ok('wrong password rejected');
  r = await anon.get('/api/feed'); assert.equal(r.status, 401); ok('feed needs a session');
  r = await amy.req('POST', '/api/posts', { text: 'x' }, { 'content-type': 'text/plain' }); assert.equal(r.status, 403); ok('non-JSON writes refused (CSRF)');
  r = await amy.req('POST', '/api/posts', { text: 'x' }, { origin: 'https://evil.example' }); assert.equal(r.status, 403); ok('cross-origin writes refused');
  r = await amy.get('/api/admin/stats'); assert.equal(r.status, 403); ok('members cannot reach the admin API');
  const me = (await amy.get('/api/me')).data.user, boMe = (await bo.get('/api/me')).data.user;

  r = await amy.post('/api/me/password', { current: 'wrong-wrong', next: 'brandnewpass1' }); assert.equal(r.status, 403);
  r = await amy.post('/api/me/password', { current: 'longenough1', next: 'brandnewpass1' }); assert.equal(r.status, 200);
  r = await amy.get('/api/me'); assert.equal(r.status, 200);
  const amy2 = client(); r = await amy2.post('/api/login', { email: 'amy@example.com', password: 'longenough1' }); assert.equal(r.status, 401);
  r = await amy2.post('/api/login', { email: 'amy@example.com', password: 'brandnewpass1' }); assert.equal(r.status, 200); ok('password change works');
  r = await amy.post('/api/me', { name: 'Amy P', bio: 'Beat Saber, mostly' }); assert.equal(r.status, 200);
  r = await amy.get('/api/me'); assert.equal(r.data.user.name, 'Amy P'); ok('profile edit');

  console.log('Uploads and posts');
  r = await up(amy, new TextEncoder().encode('this is not a video file at all')); assert.equal(r.status, 415); ok('non-media upload refused');
  r = await up(amy, mp4(2 * 1024 * 1024)); assert.equal(r.status, 413); ok('oversize upload refused');
  const clip = mp4(600 * 1024); r = await up(amy, clip); assert.equal(r.status, 200); assert.equal(r.data.mime, 'video/mp4'); const media = r.data;
  r = await amy.post('/api/posts', { text: 'First run of Beat Saber on the new headset', media: media.id, is360: false, game: 'Beat Saber' }); assert.equal(r.status, 200); const postId = r.data.id;
  r = await bo.post('/api/posts', { text: 'steal', media: media.id }); assert.equal(r.status, 400); ok("cannot attach someone else's upload");
  r = await bo.get('/api/feed'); assert.equal(r.data.posts.length, 1); assert.equal(r.data.posts[0].user.handle, 'amy'); assert.equal(r.data.posts[0].game, 'Beat Saber'); ok('post appears in the feed');
  r = await bo.req('GET', media.url, undefined, { range: 'bytes=100-199' }); assert.equal(r.status, 206); assert.equal(r.headers.get('content-range'), `bytes 100-199/${clip.length}`); const part = new Uint8Array(await r.raw.arrayBuffer()); assert.deepEqual([...part], [...clip.slice(100, 200)]); ok('video range requests work');
  r = await anon.req('GET', media.url); assert.equal(r.status, 401); ok('media is members-only');
  r = await bo.post(`/api/posts/${postId}/like`); assert.equal(r.data.liked, true); assert.equal(r.data.likes, 1);
  r = await bo.post(`/api/posts/${postId}/like`); assert.equal(r.data.likes, 0); ok('like toggles');
  r = await bo.post(`/api/posts/${postId}/comments`, { text: 'nice run' }); assert.equal(r.data.comment.user.handle, 'bobo');
  r = await bo.get(`/api/posts/${postId}/comments`); assert.equal(r.data.comments.length, 1); ok('comments');
  r = await bo.post(`/api/posts/${postId}/report`, { reason: 'spam' }); assert.equal(r.status, 200);
  r = await owner.get('/api/admin/reports'); assert.equal(r.data.reports.length, 1); assert.equal(r.data.reports[0].author, 'amy'); ok('report reaches the admin');
  r = await bo.del(`/api/posts/${postId}`); assert.equal(r.status, 403); ok('only the author or admin can delete');
  r = await owner.del(`/api/posts/${postId}`); assert.equal(r.status, 200);
  await sleep(100);
  assert.equal(existsSync(path.join(dataDir, 'uploads', media.id)), false); ok('admin removal deletes the video file');

  console.log('Follows, friends and messages');
  r = await bo.post(`/api/follow/${me.id}`); assert.equal(r.data.following, true);
  await amy.post('/api/posts', { text: 'text only post' });
  r = await bo.get('/api/feed?tab=following'); assert.equal(r.data.posts.length, 1);
  r = await owner.get('/api/feed?tab=following'); assert.equal(r.data.posts.length, 0); ok('following tab only shows followed people');
  r = await bo.get('/api/users/amy'); assert.equal(r.data.counts.followers, 1); assert.equal(r.data.user.following, true); ok('profile counts');
  const room = `d:${Math.min(me.id, boMe.id)}-${Math.max(me.id, boMe.id)}`;
  r = await amy.post('/api/chat/' + encodeURIComponent(room), { text: 'hi' }); assert.equal(r.status, 403); ok('no messaging before friendship');
  const boSse = await bo.sse();
  r = await amy.post(`/api/friends/${boMe.id}`); assert.equal(r.data.friend, 'pending_out');
  await boSse.wait('friend');
  r = await bo.get('/api/friends'); assert.equal(r.data.incoming.length, 1);
  r = await bo.post(`/api/friends/${me.id}`); assert.equal(r.data.friend, 'friends');
  r = await amy.get('/api/friends'); assert.equal(r.data.friends.length, 1); assert.equal(r.data.friends[0].room, room); ok('friend request and accept');
  r = await amy.post('/api/chat/' + encodeURIComponent(room), { text: 'hi bo' }); assert.equal(r.status, 200);
  const ev = await boSse.wait('chat'); assert.equal(ev.message.text, 'hi bo'); ok('direct message arrives live');
  r = await owner.get('/api/chat/' + encodeURIComponent(room)); assert.equal(r.status, 403); ok('strangers cannot read DMs');
  r = await bo.get('/api/chat/' + encodeURIComponent(room)); assert.equal(r.data.messages.length, 1);

  console.log('Groups');
  r = await amy.post('/api/groups', { name: 'Quest owners', description: 'Quest 3 and 3S' }); assert.equal(r.status, 200); const gid = r.data.id;
  r = await bo.post('/api/chat/' + encodeURIComponent('g:' + gid), { text: 'let me in' }); assert.equal(r.status, 403);
  r = await bo.post(`/api/groups/${gid}/join`); assert.equal(r.data.member, true);
  r = await bo.post('/api/chat/' + encodeURIComponent('g:' + gid), { text: 'hello group' }); assert.equal(r.status, 200);
  r = await amy.get('/api/chat/' + encodeURIComponent('g:' + gid)); assert.equal(r.data.messages.length, 1);
  r = await amy.get('/api/groups'); assert.equal(r.data.groups[0].members, 2); ok('groups: create, join, chat');

  console.log('Calls (signalling only)');
  const amySse = await amy.sse();
  r = await bo.post('/api/calls', { to: me.id }); const callRoom = r.data.room;
  const inv = await amySse.wait('call-invite'); assert.equal(inv.room, callRoom); assert.equal(inv.from.handle, 'bobo');
  r = await owner.post(`/api/calls/${callRoom}/join`); assert.equal(r.status, 403); ok('call invite delivered, strangers cannot join');
  r = await bo.post(`/api/calls/${callRoom}/join`); assert.deepEqual(r.data.peers, []);
  r = await amy.post(`/api/calls/${callRoom}/join`); assert.equal(r.data.peers[0].handle, 'bobo');
  await boSse.wait('rtc-join');
  r = await amy.post('/api/rtc', { room: callRoom, to: boMe.id, data: { sdp: 'offer-blob' } }); assert.equal(r.status, 200);
  const sig = await boSse.wait('rtc'); assert.equal(sig.from, me.id); assert.equal(sig.data.sdp, 'offer-blob'); ok('offer relayed between call members');
  await amy.post(`/api/calls/${callRoom}/leave`); await boSse.wait('rtc-leave'); ok('leave notifies the other side');
  r = await amy.post(`/api/calls/group/${gid}`); assert.equal(r.status, 200); await boSse.wait('call-invite'); ok('group call rings members');
  boSse.close(); amySse.close();

  console.log('Policies and your data');
  r = await anon.post('/api/register', { handle: 'noagree', name: 'No Agree', email: 'na@example.com', password: 'longenough1', invite: 'whatever' }); assert.equal(r.status, 400); assert.match(r.data.error, /accept/i); ok('joining requires accepting the rules, terms and privacy policy');
  for (const [path_, word] of [['/rules', 'Community rules'], ['/terms', 'Terms of use'], ['/privacy', 'Privacy policy'], ['/contact', 'Contact']]) {
    r = await anon.req('GET', path_); assert.equal(r.raw.status, 200); const html = await r.raw.text(); assert.ok(html.includes(word)); assert.ok(!html.includes('undefined')); assert.ok(html.includes('<link rel="stylesheet" href="/style.css">'));
  }
  r = await anon.req('GET', '/terms'); let terms = await r.raw.text(); assert.ok(terms.includes('<mark>[your state or country]</mark>')); assert.ok(terms.includes('the owner of Wraparound')); ok('policy pages are public and show what is still left to fill in');
  r = await owner.get('/api/admin/launch'); assert.equal(r.data.ready, false); assert.equal(r.data.items.find((i) => i.id === 'contact').ok, false); assert.equal(r.data.items.find((i) => i.id === 'https').ok, false);
  r = await amy.post('/api/admin/policies', { contactEmail: 'x@y.co', minAge: 16 }); assert.equal(r.status, 403);
  r = await owner.post('/api/admin/policies', { contactEmail: 'not-an-email', minAge: 16 }); assert.equal(r.status, 400);
  r = await owner.post('/api/admin/policies', { contactEmail: 'help@headset.example', minAge: 5 }); assert.equal(r.status, 400);
  const pol = (await owner.get('/api/admin/policies')).data;
  r = await owner.post('/api/admin/policies', { contactEmail: 'help@headset.example', operator: '<script>alert(1)</script> Ltd', minAge: 18, terms: pol.terms.replace('[[your state or country]]', 'Ohio, USA') }); assert.equal(r.status, 200);
  r = await anon.req('GET', '/terms'); terms = await r.raw.text();
  assert.ok(!terms.includes('<script>alert')); assert.ok(terms.includes('&lt;script&gt;alert(1)&lt;/script&gt; Ltd')); assert.ok(terms.includes('at least 18 years old')); assert.ok(terms.includes('Ohio, USA')); assert.ok(!terms.includes('<mark>')); assert.ok(terms.includes('<a href="mailto:help@headset.example">'));
  r = await anon.req('GET', '/privacy'); assert.ok((await r.raw.text()).includes('help@headset.example')); ok('editing policies updates the pages, and owner text is escaped');
  r = await owner.get('/api/admin/launch'); assert.equal(r.data.items.find((i) => i.id === 'contact').ok, true); assert.equal(r.data.items.find((i) => i.id === 'policies').ok, true); assert.equal(r.data.ready, false, 'still no https'); ok('launch checklist reflects what is done');
  r = await owner.post('/api/admin/policies/reset', { which: 'terms' }); assert.ok(r.data.text.includes('[[your state or country]]')); ok('a policy can be reset to the starting text');
  r = await anon.get('/api/config'); assert.equal(r.data.contactEmail, 'help@headset.example'); assert.equal(r.data.minAge, 18);

  const dee = client(); const invD = (await owner.post('/api/admin/invites', { count: 1 })).data.codes[0];
  r = await dee.post('/api/register', { agree: true, handle: 'deedee', name: 'Dee', email: 'dee@example.com', password: 'longenough1', invite: invD }); assert.equal(r.status, 200);
  const deeClip = await up(dee, mp4(40 * 1024)); await dee.post('/api/posts', { text: 'Dee clip', media: deeClip.data.id });
  r = await dee.req('GET', '/api/me/export'); const exp = r.data; assert.equal(r.status, 200); assert.equal(exp.profile.handle, 'deedee'); assert.equal(exp.posts.length, 1); assert.ok(exp.profile.accepted_at > 0); assert.ok(r.headers.get('content-disposition').includes('attachment')); ok('members can download their data');
  r = await dee.post('/api/me/delete', { confirm: 'wrong-pass' }); assert.equal(r.status, 403);
  r = await owner.post('/api/me/delete', { confirm: 'longenough1' }); assert.equal(r.status, 400); ok("the owner account can't be deleted by itself");
  r = await dee.post('/api/me/delete', { confirm: 'longenough1' }); assert.equal(r.status, 200); await sleep(100);
  assert.equal(existsSync(path.join(dataDir, 'uploads', deeClip.data.id)), false); r = await dee.get('/api/feed'); assert.equal(r.status, 401);
  r = await anon.post('/api/login', { email: 'dee@example.com', password: 'longenough1' }); assert.equal(r.status, 401); ok('members can delete their own account and files');

  console.log('Admin');
  r = await owner.post(`/api/admin/users/${boMe.id}`, { role: 'admin' }); assert.equal(r.status, 400); ok('admin rights cannot be handed to anyone');
  r = await owner.post('/api/admin/site', { siteName: 'Headset Club', headline: 'Clips from my crew', intro: 'Invite only.' }); assert.equal(r.status, 200);
  r = await anon.get('/api/config'); assert.equal(r.data.siteName, 'Headset Club'); assert.equal(r.data.headline, 'Clips from my crew');
  r = await amy.post('/api/admin/site', { siteName: 'Mine now' }); assert.equal(r.status, 403); ok('only the owner can edit the site text');
  r = await owner.get('/api/admin/stats'); assert.ok(r.data.users === 3 && r.data.groups === 1);
  r = await owner.post(`/api/admin/users/${boMe.id}`, { status: 'banned' }); assert.equal(r.status, 200);
  r = await bo.get('/api/feed'); assert.equal(r.status, 401); ok('banned account loses its session');
  const boAgain = client(); r = await boAgain.post('/api/login', { email: 'bo@example.com', password: 'longenough1' }); assert.equal(r.status, 200);
  r = await boAgain.get('/api/feed'); assert.equal(r.status, 403); assert.equal(r.data.error, 'banned'); ok('banned account is blocked on login');
  r = await owner.post('/api/admin/settings', { signup: 'approval' }); assert.equal(r.data.signup, 'approval');
  const cy = client(); r = await cy.post('/api/register', { agree: true, handle: 'cyc', name: 'Cy', email: 'cy@example.com', password: 'longenough1' }); assert.equal(r.status, 200);
  r = await cy.get('/api/feed'); assert.equal(r.status, 403); assert.equal(r.data.error, 'pending'); const cyMe = (await cy.get('/api/me')).data.user; assert.equal(cyMe.status, 'pending');
  r = await owner.post(`/api/admin/users/${cyMe.id}`, { status: 'active' }); r = await cy.get('/api/feed'); assert.equal(r.status, 200); ok('approval mode holds new accounts until the admin approves');
  r = await owner.post('/api/admin/settings', { signup: 'closed' }); const dz = client(); r = await dz.post('/api/register', { agree: true, handle: 'dzz', name: 'Dz', email: 'dz@example.com', password: 'longenough1' }); assert.equal(r.status, 403); ok('closed mode blocks sign-ups');
  const before = readdirSync(path.join(dataDir, 'uploads')).length;
  const up2 = await up(amy, mp4(50 * 1024)); assert.equal(up2.status, 200);
  assert.equal(readdirSync(path.join(dataDir, 'uploads')).length, before + 1);
  r = await owner.del(`/api/admin/users/${me.id}`); assert.equal(r.status, 200); await sleep(150);
  assert.equal(readdirSync(path.join(dataDir, 'uploads')).length, before); ok('deleting a member removes their files');
  r = await owner.get('/api/admin/users'); assert.equal(r.data.users.some(u => u.handle === 'amy'), false);
  r = await anon.req('GET', '/'); assert.equal(r.raw.status, 200);
  r = await anon.req('GET', '/..%2f..%2fserver.js'); assert.notEqual(r.raw.status, 200); ok('static files served, path traversal refused');
  console.log(`\n${passed} checks passed`);
} catch (e) { console.error('\nFAILED:', e); process.exitCode = 1; }
finally { proc.kill(); }
