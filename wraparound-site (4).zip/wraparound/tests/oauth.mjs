// Tests Google / Apple sign-in against a mock OpenID Connect provider that signs real JWTs.
import http from 'node:http';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const rnd = () => crypto.randomBytes(8).toString('hex');
const b64 = (o) => Buffer.from(typeof o === 'string' ? o : JSON.stringify(o)).toString('base64url');

/* ---- mock provider ---- */
const rsa = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 }), otherRsa = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const ec = crypto.generateKeyPairSync('ec', { namedCurve: 'P-256' });
const jwk = { ...rsa.publicKey.export({ format: 'jwk' }), kid: 'k1', alg: 'RS256', use: 'sig' };
const mock = { next: {}, codes: new Map(), appleSecretChecked: 0 };
const mockServer = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://m'), send = (o, c = 200) => { res.writeHead(c, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
  if (u.pathname === '/jwks') return send({ keys: [jwk] });
  if (u.pathname === '/authorize') {
    const code = rnd(); mock.codes.set(code, { nonce: u.searchParams.get('nonce'), client: u.searchParams.get('client_id'), redirect: u.searchParams.get('redirect_uri'), claims: { ...mock.next } });
    return send({ code, state: u.searchParams.get('state'), params: Object.fromEntries(u.searchParams) });
  }
  if (u.pathname === '/token') {
    let body = ''; for await (const c of req) body += c; const f = new URLSearchParams(body), info = mock.codes.get(f.get('code'));
    if (!info || info.client !== f.get('client_id') || info.redirect !== f.get('redirect_uri')) return send({ error: 'invalid_grant' }, 400);
    mock.codes.delete(f.get('code'));
    if (info.client === 'gid') { if (f.get('client_secret') !== 'gsecret') return send({ error: 'invalid_client' }, 401); }
    else {
      const [h, p, s] = f.get('client_secret').split('.'), pl = JSON.parse(Buffer.from(p, 'base64url'));
      const good = crypto.verify('sha256', Buffer.from(h + '.' + p), { key: ec.publicKey, dsaEncoding: 'ieee-p1363' }, Buffer.from(s, 'base64url'));
      if (!good || pl.iss !== 'TEAM123' || pl.sub !== 'aid' || pl.aud !== 'https://appleid.apple.com' || JSON.parse(Buffer.from(h, 'base64url')).kid !== 'KEY123') return send({ error: 'invalid_client' }, 401);
      mock.appleSecretChecked++;
    }
    const c = info.claims, t = Math.floor(Date.now() / 1000);
    const payload = { iss: c.iss ?? (info.client === 'gid' ? 'https://mock.test/google' : 'https://mock.test/apple'), aud: c.aud ?? info.client, sub: c.sub, email: c.email, email_verified: c.email_verified, name: c.name, nonce: c.nonce ?? info.nonce, iat: t, exp: c.expired ? t - 3600 : t + 300 };
    const data = b64({ alg: 'RS256', kid: 'k1' }) + '.' + b64(payload);
    const sig = crypto.sign('RSA-SHA256', Buffer.from(data), (c.signWith === 'other' ? otherRsa : rsa).privateKey).toString('base64url');
    return send({ id_token: data + '.' + sig, access_token: 'unused' });
  }
  send({ error: 'nope' }, 404);
});
await new Promise((r) => mockServer.listen(0, '127.0.0.1', r));
const M = `http://127.0.0.1:${mockServer.address().port}`;

/* ---- real server ---- */
const PORT = 4700 + Math.floor(Math.random() * 400), BASE = `http://127.0.0.1:${PORT}`;
const dataDir = mkdtempSync(path.join(tmpdir(), 'wrap-oa-'));
const proc = spawn(process.execPath, ['--no-warnings', 'server.js'], { cwd: root, stdio: ['ignore', 'pipe', 'inherit'], env: { ...process.env, PORT, DATA_DIR: dataDir, SIGNUP_MODE: 'invite', PUBLIC_URL: BASE, COOKIE_SECURE: '0',
  GOOGLE_CLIENT_ID: 'gid', GOOGLE_CLIENT_SECRET: 'gsecret', GOOGLE_AUTH_URL: M + '/authorize', GOOGLE_TOKEN_URL: M + '/token', GOOGLE_JWKS_URL: M + '/jwks', GOOGLE_ISSUER: 'https://mock.test/google',
  APPLE_CLIENT_ID: 'aid', APPLE_TEAM_ID: 'TEAM123', APPLE_KEY_ID: 'KEY123', APPLE_PRIVATE_KEY: ec.privateKey.export({ type: 'pkcs8', format: 'pem' }).replace(/\n/g, '\\n'),
  APPLE_AUTH_URL: M + '/authorize', APPLE_TOKEN_URL: M + '/token', APPLE_JWKS_URL: M + '/jwks', APPLE_ISSUER: 'https://mock.test/apple' } });
await new Promise((res, rej) => { proc.stdout.on('data', (d) => String(d).includes('running') && res()); proc.on('exit', (c) => rej(new Error('server exited ' + c))); setTimeout(() => rej(new Error('start timeout')), 8000); });

let passed = 0; const ok = (n) => { passed++; console.log('  ok  ' + n); };
const jar = () => ({ cookies: {} });
async function raw(j, method, url, body, ctype) {
  const cookie = Object.entries(j.cookies).filter(([, v]) => v).map(([k, v]) => `${k}=${v}`).join('; ');
  const headers = { cookie }; if (ctype) headers['content-type'] = ctype;
  const r = await fetch(BASE + url, { method, headers, body, redirect: 'manual' });
  for (const sc of r.headers.getSetCookie()) { const [kv] = sc.split(';'); const i = kv.indexOf('='); j.cookies[kv.slice(0, i)] = kv.slice(i + 1); }
  const ct = r.headers.get('content-type') || '';
  return { status: r.status, location: r.headers.get('location'), data: ct.includes('json') ? await r.json() : null };
}
const api = (j, method, url, body) => raw(j, method, url, method === 'GET' ? undefined : JSON.stringify(body ?? {}), method === 'GET' ? undefined : 'application/json');
const errOf = (loc) => new URL(loc, BASE).searchParams.get('auth_error');

async function social(j, provider, claims, o = {}) {
  mock.next = claims;
  const qs = new URLSearchParams(); if (o.invite) qs.set('invite', o.invite); if (o.link) qs.set('link', '1'); if (!o.noAgree) qs.set('agree', '1');
  const start = await raw(j, 'GET', `/auth/${provider}/start${qs.size ? '?' + qs : ''}`);
  if (!start.location || !start.location.startsWith(M)) return start;
  const a = await (await fetch(start.location)).json();
  assert.equal(a.params.redirect_uri, `${BASE}/auth/${provider}/callback`);
  assert.ok(a.params.state && a.params.nonce);
  const state = o.state ?? a.state;
  if (provider === 'google') return raw(j, 'GET', `/auth/google/callback?code=${a.code}&state=${state}`);
  assert.equal(a.params.response_mode, 'form_post');
  const f = new URLSearchParams({ code: a.code, state }); if (o.user) f.set('user', JSON.stringify(o.user));
  return raw(j, 'POST', '/auth/apple/callback', f.toString(), 'application/x-www-form-urlencoded');
}
const good = (sub, email, name) => ({ sub, email, email_verified: true, name });

try {
  const j = jar();
  let r = await api(j, 'GET', '/api/config'); assert.deepEqual(r.data.providers, { google: true, apple: true }); ok('config lists the configured providers');

  console.log('Google');
  r = await social(j, 'google', good('g-owner', 'host@example.com', 'Host Person')); assert.equal(r.status, 303); assert.equal(r.location, '/#/'); assert.ok(j.cookies.sid);
  let me = (await api(j, 'GET', '/api/me')).data.user;
  assert.equal(me.role, 'admin'); assert.equal(me.name, 'Host Person'); assert.match(me.handle, /^host/); assert.equal(me.hasPassword, false); assert.equal(me.identities[0].provider, 'google'); ok('first Google sign-in creates the owner account');
  const j2 = jar(); r = await social(j2, 'google', good('g-owner', 'host@example.com', 'Host Person')); assert.equal(r.location, '/#/');
  assert.equal((await api(j2, 'GET', '/api/me')).data.user.id, me.id); ok('signing in again finds the same account');

  r = await social(jar(), 'google', good('g-2', 'newbie@example.com', 'New Bie')); assert.match(errOf(r.location), /invite/i); ok('invite-only mode blocks Google sign-up without an invite');
  const codes = (await api(j, 'POST', '/api/admin/invites', { count: 4 })).data.codes;
  const j3 = jar(); r = await social(j3, 'google', good('g-2', 'newbie@example.com', 'New Bie'), { invite: codes[0] }); assert.equal(r.location, '/#/');
  assert.equal((await api(j3, 'GET', '/api/me')).data.user.status, 'active');
  r = await social(jar(), 'google', good('g-3', 'second@example.com', 'Second'), { invite: codes[0] }); assert.match(errOf(r.location), /invite/i); ok('invite is accepted once and consumed');

  const pat = jar(); r = await api(pat, 'POST', '/api/register', { agree: true, handle: 'pat', name: 'Pat', email: 'pat@example.com', password: 'longenough1', invite: codes[1] }); assert.equal(r.status, 200);
  r = await social(jar(), 'google', good('g-pat-other', 'pat@example.com', 'Imposter'), { invite: codes[2] }); assert.match(errOf(r.location), /already exists/); ok('never auto-links to an existing email (no account takeover)');
  r = await social(jar(), 'google', { sub: 'g-unv', email: 'unverified@example.com', email_verified: false }, { invite: codes[2] }); assert.match(errOf(r.location), /verified/); ok('unverified provider email is refused');

  console.log('Token and state checks');
  r = await social(jar(), 'google', good('g-x', 'x@example.com'), { invite: codes[2], state: 'forged' }); assert.match(errOf(r.location), /expired/); ok('forged state refused');
  for (const [label, bad] of [['wrong nonce', { nonce: 'other' }], ['wrong audience', { aud: 'someone-else' }], ['expired token', { expired: true }], ['wrong issuer', { iss: 'https://evil.test' }], ['bad signature', { signWith: 'other' }]]) {
    r = await social(jar(), 'google', { ...good('g-bad-' + label, 'bad@example.com'), ...bad }, { invite: codes[2] });
    assert.ok(errOf(r.location), label + ' should be refused'); assert.equal(r.location.startsWith('/?auth_error='), true);
  }
  me = null; assert.equal((await api(owner(), 'GET', '/api/me')).status, 401); ok('wrong nonce, audience, issuer, expiry and signature all refused');
  function owner() { return jar(); }
  const none = await api(jar(), 'GET', '/api/admin/users'); assert.equal(none.status, 401);
  assert.equal((await api(j, 'GET', '/api/admin/users')).data.users.some((u) => u.email === 'bad@example.com'), false); ok('failed attempts created no accounts');

  console.log('Apple');
  const aj = jar(); r = await social(aj, 'apple', { sub: 'a-1', email: 'ally@example.com', email_verified: 'true' }, { invite: codes[2], user: { name: { firstName: 'Ally', lastName: 'Lee' } } });
  assert.equal(r.location, '/#/'); me = (await api(aj, 'GET', '/api/me')).data.user; assert.equal(me.name, 'Ally Lee'); assert.equal(me.identities[0].provider, 'apple');
  assert.ok(mock.appleSecretChecked >= 1); ok('Apple form_post sign-in works, with a valid ES256 client secret');
  const aj2 = jar(); r = await social(aj2, 'apple', { sub: 'a-1', email: 'private@relay.example', email_verified: 'true' }); assert.equal((await api(aj2, 'GET', '/api/me')).data.user.id, me.id); ok('Apple returns the same account on later sign-ins');

  console.log('Connecting and disconnecting');
  r = await social(pat, 'google', good('g-pat', 'pat.work@example.com', 'Pat'), { link: true }); assert.equal(r.location, '/#/me');
  let pme = (await api(pat, 'GET', '/api/me')).data.user; assert.equal(pme.hasPassword, true); assert.deepEqual(pme.identities.map((i) => i.provider), ['google']);
  const pat2 = jar(); r = await social(pat2, 'google', good('g-pat', 'pat.work@example.com', 'Pat')); assert.equal((await api(pat2, 'GET', '/api/me')).data.user.id, pme.id); ok('a signed-in member can connect Google, then sign in with it');
  r = await social(jar(), 'google', good('g-pat', 'pat.work@example.com', 'Pat'), { link: true }); assert.match(errOf(r.location), /Sign in first/); ok('connecting needs an existing session');
  r = await social(aj, 'google', good('g-pat', 'pat.work@example.com', 'Pat'), { link: true }); assert.match(errOf(r.location), /already connected/); ok('a provider account cannot be attached to two people');
  r = await api(aj, 'POST', '/api/me/identities/apple/disconnect'); assert.equal(r.status, 400); ok('cannot disconnect the only way in');
  r = await api(aj, 'POST', '/api/me/password', { next: 'brandnewpass1' }); assert.equal(r.status, 200);
  r = await api(aj, 'POST', '/api/me/identities/apple/disconnect'); assert.equal(r.status, 200);
  const ej = jar(); r = await api(ej, 'POST', '/api/login', { email: 'ally@example.com', password: 'brandnewpass1' }); assert.equal(r.status, 200); ok('a social account can add a password, then disconnect');
  r = await api(pat, 'POST', '/api/me/identities/google/disconnect'); assert.equal(r.status, 200);

  console.log('Agreement and deleting');
  r = await social(jar(), 'google', good('g-noagree', 'noagree@example.com', 'No Agree'), { invite: codes[3], noAgree: true }); assert.match(errOf(r.location), /accept the Rules/); ok('a new Google account needs the agreement box ticked');
  const dj = jar(); r = await social(dj, 'google', good('g-del', 'deleteme@example.com', 'Delete Me'), { invite: codes[3] }); assert.equal(r.location, '/#/');
  const dme = (await api(dj, 'GET', '/api/me')).data.user; assert.equal(dme.hasPassword, false);
  r = await api(dj, 'POST', '/api/me/delete', { confirm: 'someone-else' }); assert.equal(r.status, 403);
  r = await api(dj, 'POST', '/api/me/delete', { confirm: dme.handle.toUpperCase() }); assert.equal(r.status, 200);
  r = await api(dj, 'GET', '/api/me'); assert.equal(r.status, 401);
  r = await social(jar(), 'google', good('g-del', 'deleteme@example.com', 'Delete Me'), { noAgree: true }); assert.match(errOf(r.location), /accept the Rules/); ok('a Google/Apple account is deleted by typing the username');

  console.log('Modes and profile');
  await api(j, 'POST', '/api/admin/settings', { signup: 'approval' });
  const pj = jar(); r = await social(pj, 'google', good('g-pend', 'pending@example.com', 'Pending')); assert.equal(r.location, '/#/'); assert.equal((await api(pj, 'GET', '/api/me')).data.user.status, 'pending'); ok('approval mode holds Google sign-ups');
  await api(j, 'POST', '/api/admin/settings', { signup: 'closed' });
  r = await social(jar(), 'google', good('g-closed', 'closed@example.com', 'Closed')); assert.match(errOf(r.location), /closed/); ok('closed mode blocks Google sign-ups');
  r = await api(j, 'POST', '/api/me', { name: 'Host Person', bio: '', handle: 'hostess' }); assert.equal(r.status, 200); assert.equal((await api(j, 'GET', '/api/me')).data.user.handle, 'hostess');
  r = await api(j, 'POST', '/api/me', { name: 'Host Person', bio: '', handle: 'pat' }); assert.equal(r.status, 409); ok('username can be changed, duplicates refused');
  console.log(`\n${passed} checks passed`);
} catch (e) { console.error('\nFAILED:', e); process.exitCode = 1; }
finally { proc.kill(); mockServer.close(); }
